#include "TestQueue.hpp"

void printResult(bool result, string testName) {
	std::cout << "Test " << testName << " " <<
		(result ? "PASSED" : "FAILED") << "." << std::endl;
}

bool testEnqueueEmpty() {
	Queue q;
	q.enqueue("1");

	if (!q.isEmpty() && q.peek() == "1" && q.size() == 1)
		return 1;
	
	return 0;
}
bool testEnqueueOne() {
	Queue q;
	q.enqueue("1");
	q.enqueue("2");

	if (!q.isEmpty() && q.peek() == "1" && q.size() == 2)
		return 1;

	return 0;
}
bool testDequeueOne() {
	Queue q;
	q.enqueue("1");

	string ret = q.dequeue();

	if (q.isEmpty() && ret == "1" && q.size() == 0)
		return 1;
	
	return 0;
}
bool testDequeueTwo() {
	Queue q;
	q.enqueue("1");
	q.enqueue("2");

	string ret1 = q.dequeue();
	string ret2 = q.dequeue();

	if (q.isEmpty() && ret1 == "1" && ret2 == "2" && q.size() == 0)
		return 1;

	return 0;
}
void testAll() {
	printResult(testEnqueueEmpty(), "Enqueue Empty");
	printResult(testEnqueueOne(), "Enqueue One");
	printResult(testDequeueOne(), "Dequeue One");
	printResult(testDequeueTwo(), "Dequeue Two");
}