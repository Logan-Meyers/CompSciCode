#ifndef QUEUE_NODE_H
#define QUEUE_NODE_H

#include <string>
#include <iostream>

using std::string;

class QueueNode {

public:
	// constructors & destructors
	QueueNode();
	QueueNode(string newData);
	QueueNode(const QueueNode& copy);
	~QueueNode();

	QueueNode& operator=(const QueueNode& rhs);

	// getters
	QueueNode* getNext() const;
	string getData() const;

	// setters
	void setNext(QueueNode* newPtr);
	void setData(const string newData);

private:
	QueueNode* mpNext;
	string mData;  // replacing this in PA
};

#endif