#include "Queue.hpp"

// constructors & destructors
Queue::Queue() : mpHead(nullptr), mpTail(nullptr) {}
Queue::Queue(const Queue& copy) {
	// deep copy

	// start from head
	QueueNode* pCur = copy.mpHead;
	while (pCur != nullptr) {
		// go through each node in copy
		// insert into this queue a new node with same data in copy
		enqueue(pCur->getData());

		pCur = pCur->getNext();
	}
}
Queue::~Queue() {
	destroyQueue();
}

Queue& Queue::operator=(const Queue& rhs) {
	// deep copy

	// destroy old nodes
	destroyQueue();

	// start from head
	QueueNode* pCur = rhs.mpHead;
	while (pCur != nullptr) {
		// go through each node in copy
		// insert into this queue a new node with same data in copy
		enqueue(pCur->getData());

		pCur = pCur->getNext();
	}

	return *this;
}

// queue core
bool Queue::enqueue(const string newData) {
	// create space for new node
	QueueNode* pMem = new QueueNode(newData);

	// node creation failed
	if (pMem == nullptr) return false;

	// empty queue
	if (mpTail == nullptr) {
		mpHead = mpTail = pMem;
	}
	// full queue
	else {
		mpTail->setNext(pMem);
		mpTail = pMem;
	}

	return true;
}
string Queue::dequeue() {
	QueueNode* pTemp = mpHead;    // tmp to one to delete
	mpHead = mpHead->getNext();   // move along head
	string data = pTemp->getData();  // get copy of data
	delete pTemp;

	if (mpHead == nullptr) mpTail = nullptr;  // handle now empty queue

	return data;
}

// helpers
bool Queue::isEmpty() const { return mpHead == nullptr; }
string Queue::peek() const { return mpHead->getData(); }
int Queue::size() const {
	int s = 0;

	QueueNode* pCur = mpHead;
	for (; pCur != nullptr; pCur = pCur->getNext())
		s++;

	return s;
}
void Queue::destroyQueue() {
	while (mpHead != nullptr) {
		dequeue();
	}
}
void Queue::printQueueRecursive() const {
	printQueueRecursive(mpHead);
}

void Queue::printQueueRecursive(const QueueNode* head) const {
	if (head == nullptr) {
		return;
	}

	std::cout << head->getData() << std::endl;
	printQueueRecursive(head->getNext());
}