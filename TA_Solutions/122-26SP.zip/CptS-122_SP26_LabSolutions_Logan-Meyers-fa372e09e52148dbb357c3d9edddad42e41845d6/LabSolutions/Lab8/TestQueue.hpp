#ifndef TEST_QUEUE_H
#define TEST_QUEUE_H

#include "Queue.hpp"

void printResult(bool result, string testName);
bool testEnqueueEmpty();
bool testEnqueueOne();
bool testDequeueOne();
bool testDequeueTwo();
void testAll();

#endif