#ifndef QUEUE_H
#define QUEUE_H

#include "QueueNode.hpp"

class Queue {

public:
	// constructors & destructors
	Queue();
	Queue(const Queue& copy);
	~Queue();

	Queue& operator=(const Queue& rhs);

	// queue core
	bool enqueue(const string newData);
	string dequeue();

	// helpers
	bool isEmpty() const;
	string peek() const;  // useful for debugging
	int size() const;     // useful for debugging
	void destroyQueue();
	void printQueueRecursive() const;  // public facing

private:
	QueueNode* mpHead,
			 * mpTail;

	void printQueueRecursive(const QueueNode* head) const;  // private access only
};

#endif