#include "QueueNode.hpp"

// constructors & destructors
QueueNode::QueueNode() : mpNext(nullptr), mData("") {}  // a()
QueueNode::QueueNode(string newData) : mpNext(nullptr), mData(newData) {  // a("g")
	// call other functions here
}
QueueNode::QueueNode(const QueueNode& copy) : mpNext(copy.mpNext), mData(copy.mData) {}
// a(b)
QueueNode::~QueueNode() {}

QueueNode& QueueNode::operator=(const QueueNode& rhs) {
	// QueueNode a("a"), b("b");
	// a = b;

	mpNext = rhs.mpNext;
	mData = rhs.mData;

	return *this;
}

// getters
QueueNode* QueueNode::getNext() const {
	return this->mpNext;
}
string QueueNode::getData() const {
	return this->mData;
}

// setters
void QueueNode::setNext(QueueNode* newPtr) {
	this->mpNext = newPtr;
}
void QueueNode::setData(const string newData) {
	this->mData = newData;
}