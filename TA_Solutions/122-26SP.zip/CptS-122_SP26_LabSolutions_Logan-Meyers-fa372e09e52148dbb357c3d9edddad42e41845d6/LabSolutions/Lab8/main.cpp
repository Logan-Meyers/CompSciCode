#include "Queue.hpp"
#include "TestQueue.hpp"

int main() {
	testAll();

	return 0;
}