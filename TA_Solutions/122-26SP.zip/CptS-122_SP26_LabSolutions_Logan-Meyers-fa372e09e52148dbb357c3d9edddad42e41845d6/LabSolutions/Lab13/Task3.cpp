// Task3.cpp
#include "Task3.h"
void Base::testFunction()
{
	cout << "Base class" << endl;
}
void Derived::testFunction()
{
	cout << "Derived class" << endl;
}