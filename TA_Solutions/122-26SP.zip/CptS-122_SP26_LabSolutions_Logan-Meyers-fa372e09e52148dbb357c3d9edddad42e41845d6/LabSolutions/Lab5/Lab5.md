# Lab 5 Answers

1. Given the following C code:

```c
/* Line 1:  */  int n1 = 10, n2 = 42, list[] = {6, 8, 42, 3, 2, 2, -6};
/* Line 2:  */  int * const p1 = &n1;
/* Line 3:  */  const int * p2 = &n1;
/* Line 4:  */  int * p3 = list;
/* Line 5:  */  const int * const p4 = NULL;

/* Line 6:  */  *p1 = 15;
/* Line 7:  */  p1 = &n2;

/* Line 8:  */  p2 = &n2;
/* Line 9:  */  *p2 = 67;

/* Line 10: */  p3[4] = 67;

/* Line 11: */  list = &n1;

/* Line 12: */  p4 = list;
/* Line 13: */  *p4 = 25;
```

Answers:
<ol type="a">
    <li>Yes. <code>p1</code> is a constant pointer to and integer, while <code>p2</code> is a pointer to a constant integer.</li>
    <li>Yes, the pointer never changes but the value does</li>
    <li>No, since the pointer changes</li>
    <li>Yes, since the pointer is allowed to change</li>
    <li>No, since the indirect value is changing (is const)</li>
    <li>Yes, is the same as saying <code>list[3] = 67</code></li>
    <li>Yes, <code>list</code> is a pointer to an int, so technically yes even though you'd be leaking memory</li>
    <li>No, direct value can't change</li>
    <li>No, indirect value can't change</li>
</ol>

--- 

2. Copying a string to heap:

```c
char* copyStrToHeap(char* pStr) {
    // get length of string (not including null char at end)
    int length = strlen(pStr);

    // try to allocate space for the string on the heap
    char* heapStr = (char*)malloc((length + 1) * sizeof(char));
    if (heapStr == NULL) return NULL;  // failed

    // copy string chars and add null char at end
    strncpy(heapStr, pStr, length);
    heapStr[length] = '\0';

    // return pointer to heap-allocated string
    return heapStr;
}
```

---

3. Other `<string.h>` functions!

Definitely take a look at the following in your own time:
- memset () - http://www.cplusplus.com/reference/cstring/memset/
- memcpy () - http://www.cplusplus.com/reference/cstring/memcpy/
- memcmp () - http://www.cplusplus.com/reference/cstring/memcmp/
- memchr () - http://www.cplusplus.com/reference/cstring/memchr/

Yes, `strncpy` can be replaced by `memcpy`.

Yes, `memcpy` can be used to copy structs!

---

4. Here is one solution to merge any number of singly linked lists in order, ascending or descending.

*NOTE: this is not efficient. This assumes that the lists are NOT actually pre-sorted, and is a pretty brute-force approach.*

*NOTE: This also is non-destructive; meaning, the lists passed in are not modified at all, and this makes a copy of all the data and puts them all into a new list (which is passed back as return value). This does take twice the memory space.*

**I encourage you to make your own!**

```c
Node* mergeLists(Node* lists[], int numLists, int direction) {
	// base cases - no lists, no num lists given, and 0 direction
	if (lists == NULL || numLists <= 0 || direction == 0) return NULL;

	// this is the not most space-efficient, but I am going to set up copies
	// of the original lists that we can edit. I say this because I want to be
	// able to remove items as we go so it's easy to keep track of what
	// we have and haven't already moved. This is only an issue IF WE ALLOW DUPLICATES
	// in the list. THERE ARE BETTER WAYS TO DO THIS
	Node **listsCpy = (Node**)malloc(numLists * sizeof(Node*));
	if (listsCpy == NULL) return NULL;

	for (int i = 0; i < numLists; i++) {
		Node *pCur = lists[i];
		listsCpy[i] = NULL;  // null initially

		while (pCur != NULL) {
			insertBack(&listsCpy[i], pCur->data);
			pCur = pCur->pNext;
		}
	}

	// set up variables for algorithm
	Node *mergedList = NULL;  // merged list pointer
	int bestIdx, bestValue, lastVal;  // best value and index in lists for current loop

	// set last based on direction once
	if (direction < 0) {
		lastVal = INT_MAX;
	}
	else {
		lastVal = INT_MIN;
	}

	// loop to find best value, then push and pop
	while (anyNonNull(listsCpy, numLists)) {
		// set best based on direction
		if (direction < 0) {
			bestIdx = INT_MIN;
			bestValue = INT_MIN;
		}
		else {
			bestIdx = INT_MAX;
			bestValue = INT_MAX;
		}

		// loop through lists to find next best value list by list
		for (int i = 0; i < numLists; i++) {
			// skip index if no list left
			if (listsCpy[i] == NULL) continue;

			// loop through list to find best value for this list
			Node *pCur = listsCpy[i];

			while (pCur != NULL) {
				// check data against current best and last
				if (direction < 0) {  // descending
					if (pCur->data > bestValue && pCur->data <= lastVal) {
						bestIdx = i;
						bestValue = pCur->data;
					}
				}
				else {  // ascending
					if (pCur->data < bestValue && pCur->data >= lastVal) {
						bestIdx = i;
						bestValue = pCur->data;
					}
				}

				// walk along list
				pCur = pCur->pNext;
			}
		}

		printf("Found best value of %d in list index %d\n", bestValue, bestIdx);

		// insert at back in merged list
		insertBack(&mergedList, bestValue);

		// remove from list we are taking from
		removeNode(&listsCpy[bestIdx], bestValue);

		// set new last val
		lastVal = bestValue;
	}

	return mergedList;
}

int anyNonNull(Node* lists[], int numLists) {
	for (int i = 0; i < numLists; i++)
		if (lists[i] != NULL) return 1;

	return 0;
}
```

---

5. To find a loop in one pass, use a variation on the [Floyd's tortoise and hare algorithm](https://en.wikipedia.org/wiki/Cycle_detection#:~:text=Floyd%27s%20tortoise%20and%20hare,-%5Bedit)

```c
int detectLoop(Node* list) {
	// based on Floyd's Tortoise and Hare algorithm

	Node *slow = list,
		 *fast = list;
	
	while (fast != NULL && fast->pNext != NULL) {
		// move slow by 1
		slow = slow->pNext;

		// move fast by 2
		fast = fast->pNext->pNext;

		// slow and fast will intersect (be equal) if there is a loop eventually
		if (slow == fast) return 1;
	}

	return 0;
}
```

---

6. Singly-linked list reversing in one pass:

```c
Node* reverseList(Node** list) {
	// base case: empty list
	if (*list == NULL) return NULL;

	// base case: one node
	if ((*list)->pNext == NULL) return *list;
	
	// pointers for reversing
	Node *pPrev = NULL;
	Node *pCur = *list;
	Node* pNext = (*list)->pNext;

	// loop to reverse list
	while (pCur != NULL) {
		// swap pointers
		pCur->pNext = pPrev;

		// walk list
		pPrev = pCur;
		pCur = pNext;
		pNext = pNext->pNext;
	}

	// set new head
	*list = pPrev;

	return *list;
}
```

---

7. List via array vs linked list

_Implementing a list using an array is done by simply using an array; fixed size._

<ol type="a">
    <li>Array - instantly know where to delete.</li>
    <li>Linked list - just move head pointer and delete. No space left in the beginning like would be in an array.</li>
    <li>Linked list - deleting in general involves deleting anywhere in the list. It's easier to find a node, delete it, and fix links than to shift over items in an array.</li>
    <li>Array - instantly know where to insert. Would need to walk through list to find end, unless you have a tail pointer.</li>
    <li>Linked list - just make node, set link, and change head pointer. Array would require shifting everything over.</li>
    <li>Linked list - one walk through list to find item, then instant delete. Array requires walking through list if you don't know where it is, then shifting everything over after deleting.</li>
    <li>Array - if you know where the item is, any access is insant. Otherwise they would be equal if you have to find an item (walk list either way).</li>
</ol>

---

8. Maze

*Check out my [solution from Lab 4](https://github.com/Logan-Meyers/CptS-122_SP26_LabSolutions_Logan-Meyers/releases/tag/Lab4)!*