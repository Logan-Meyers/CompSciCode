#pragma once

#ifndef HEAP_STRING_H
#define HEAP_STRING_H

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char* copyStrToHeap(char* pStr);
char* copyStrToHeapMem(char* pStr);

void demoStrToHeap();
void demoStrToHeapMem();

#endif
