#include "heapstring.h"

char* copyStrToHeap(char* pStr) {
    // get length of string (not including null char at end)
    int length = strlen(pStr);

    // try to allocate space for the string on the heap
    char* heapStr = (char*)malloc((length + 1) * sizeof(char));
    if (heapStr == NULL) return NULL;  // failed

    // copy string chars and add null char at end
    strncpy(heapStr, pStr, length);
    heapStr[length] = '\0';

    // return pointer to heap-allocated string
    return heapStr;
}

char* copyStrToHeapMem(char* pStr) {
    // get length of string (not including null char at end)
    int length = strlen(pStr);

    // try to allocate space for the string on the heap
    char* heapStr = (char*)malloc((length + 1) * sizeof(char));
    if (heapStr == NULL) return NULL;  // failed

    // copy string chars and add null char at end
    memcpy(heapStr, pStr, length);
    heapStr[length] = '\0';

    // return pointer to heap-allocated string
    return heapStr;
}

void demoStrToHeap() {
    printf("\n----- String to Heap (strncpy) -----\n");

    char* src = "HEllo!";
    char* src2 = "";

    printf("\"%s\" --> \"%s\"\n", src, copyStrToHeap(src));
    printf("\"%s\" --> \"%s\"\n", src2, copyStrToHeap(src2));
}

void demoStrToHeapMem() {
    printf("\n----- String to Heap (memcpy) -----\n");

    char* src = "HEllo!";
    char* src2 = "";

    printf("\"%s\" --> \"%s\"\n", src, copyStrToHeapMem(src));
    printf("\"%s\" --> \"%s\"\n", src2, copyStrToHeapMem(src2));
}
