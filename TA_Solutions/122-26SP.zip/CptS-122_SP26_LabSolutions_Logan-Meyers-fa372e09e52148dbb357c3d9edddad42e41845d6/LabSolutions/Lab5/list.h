#pragma once

#ifndef LIST_H
#define LIST_H

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

/* ------------------------------ singly Linked List Definitions ------------------------------ */

typedef struct node
{
	int data;
	struct node* pNext;
} Node;

/* ------------------------------ Demo Functions ------------------------------ */

void demoMerge();
void demoLoop();
void demoReverse();

/* ------------------------------ Singly Linked List Functions ------------------------------ */

// Description: Allocates space for a Node on the heap and initializes
// the Node with the information found in newData.
// Returns: The address of the start of the block of memory on the heap
// or NULL if no memory was allocated
Node* createNode(int newData);

// description: adds an item to the front of the list
// returns: success
int insertFront(Node** pList, int newData);

// description: adds an item to the end of the list
// returns: success
int insertBack(Node** pList, int newData);

// description: removes the first node which has matching data
// returns: whether node found and deleted
int removeNode(Node** pList, int dataToDel);

void destroy(Node** list);

// Description: Prints all contact information in the list
// Returns: Nothing
void printList(Node* pList);

/* ------------------------------ Task Functions ------------------------------ */

// description: Merge one or more lists into a new list in asc or desc order
// note: doesn't modify original lists
// returns: pointer to merged list
Node* mergeLists(Node* lists[], int numLists, int direction);

// description: checks if there are any non-empty lists in the array
// note: helper for mergeLists
// returns: 1 or 0, true or false
int anyNonNull(Node *lists[], int numLists);

// description: detect if a list has a loop or not
// returns: 1 or 0, true or false
int detectLoop(Node* list);

// description: reverse a singly linked list in one pass
// returns: Node* pointer to new head of list
Node* reverseList(Node** list);

#endif