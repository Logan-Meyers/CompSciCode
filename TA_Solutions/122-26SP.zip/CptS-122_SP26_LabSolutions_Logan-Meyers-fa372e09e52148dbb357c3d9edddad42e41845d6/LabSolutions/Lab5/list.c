#include "list.h"

/* ------------------------------ Demo Functions ------------------------------ */

void demoMerge() {
	printf("\n----- Merge Lists -----\n");

	Node* lists[3] = {NULL, NULL, NULL};
	
	// first list - 1 3 5 7
	insertBack(&lists[0], 1);
	insertBack(&lists[0], 3);
	insertBack(&lists[0], 5);
	insertBack(&lists[0], 7);

	// second list - 2 4 6
	insertBack(&lists[1], 2);
	insertBack(&lists[1], 4);
	insertBack(&lists[1], 6);

	// third list - 1 5 2 7 3 3 3 7
	insertBack(&lists[2], 1);
	insertBack(&lists[2], 5);
	insertBack(&lists[2], 2);
	insertBack(&lists[2], 7);
	insertBack(&lists[2], 3);
	insertBack(&lists[2], 3);
	insertBack(&lists[2], 3);
	insertBack(&lists[2], 7);

	// before merge
	printf("First list: ");
	printList(lists[0]);

	printf("Second list: ");
	printList(lists[1]);

	printf("Third list: ");
	printList(lists[2]);

	Node* mergedAsc = mergeLists(lists, 3, 1);
	Node* mergedDesc = mergeLists(lists, 3, -1);

	printf("\nMerged list (ascending): ");
	printList(mergedAsc);

	printf("\nMerged list (descending): ");
	printList(mergedDesc);

	for (int i = 0; i < 3; i++)
		destroy(&lists[i]);

	destroy(&mergedAsc);
	destroy(&mergedDesc);
}

void demoLoop() {
	printf("\n----- Detect Loop in List -----\n");

	Node *list = NULL;
	insertBack(&list, 1);
	insertBack(&list, 3);
	insertBack(&list, 5);
	insertBack(&list, 7);

	printf("Checking loop in list: ");
	printList(list);

	printf("\nNon looping: ");
	if (detectLoop(list) == 1)
		printf("Loop detected!");
	else
		printf("No loop detected.");

	list->pNext->pNext->pNext->pNext = list;  // full loop
	printf("\nFull loop: ");
	if (detectLoop(list) == 1)
		printf("Loop detected!");
	else
		printf("No loop detected.");

	list->pNext->pNext->pNext->pNext = list->pNext;  // two nodes before loop
	printf("\nTwo nodes before loop: ");
	if (detectLoop(list) == 1)
		printf("Loop detected!");
	else
		printf("No loop detected.");

	list->pNext->pNext->pNext->pNext = list->pNext->pNext;  // one node before loop
	printf("\nOne node before loop: ");
	if (detectLoop(list) == 1)
		printf("Loop detected!");
	else
		printf("No loop detected.");

	list->pNext->pNext->pNext->pNext = list->pNext->pNext->pNext;  // end to itself
	printf("\nLoop to itself at end: ");
	if (detectLoop(list) == 1)
		printf("Loop detected!");
	else
		printf("No loop detected.");

	list->pNext->pNext->pNext->pNext = NULL;  // fix loop for destroy

	destroy(&list);
}

void demoReverse() {
	printf("\n----- Reverse List -----\n");

	Node *list = NULL;

	for (int i = 0; i < 15; i++) {
		insertBack(&list, i);
	}

	printf("List before: ");
	printList(list);

	reverseList(&list);
	printf("List after reverse: ");
	printList(list);

	destroy(&list);
}

/* ------------------------------ Singly Linked List Functions ------------------------------ */

Node* createNode(int newData) {
	Node* pMem = malloc(sizeof(Node)); // allocating 54 or 58 bytes

	if (pMem != NULL)
	{
		// we allocated a Node successfully on the heap

		// we can now initialize it
		pMem->data = newData; // struct assignment
		pMem->pNext = NULL;
	}

	return pMem;
}

int insertFront(Node** pList, int newData) {
	Node* newNode = createNode(newData);

	if (newNode == NULL) return 0;

	newNode->pNext = *pList;

	*pList = newNode;

	return 1;
}

int insertBack(Node** pList, int newData) {
	Node* newNode = createNode(newData);

	if (newNode == NULL) return 0;

	// set start of list if empty list

	if (*pList == NULL) {
		*pList = newNode;
		return 1;
	}
	
	// find back of list
	Node* pCur = *pList;

	while (pCur->pNext != NULL)
		pCur = pCur->pNext;

	pCur->pNext = newNode;

	return 1;
}

int removeNode(Node** pList, int dataToDel) {
	Node *pCur = *pList;
	Node *pPrev = NULL;

	while (pCur != NULL && pCur->data != dataToDel) {
		pPrev = pCur;
		pCur = pCur->pNext;
	}

	// no node found
	if (pCur == NULL) return 0;

	// node at start
	if (pCur == *pList || pPrev == NULL) {
		*pList = pCur->pNext;
	}
	else {
		pPrev->pNext = pCur->pNext;
	}

	return 1;
}

void destroy(Node** list) {
	while (*list != NULL) {
		Node* next = (*list)->pNext;
		free(*list);
		*list = next;
	}
}

void printList(Node* pList) {
	Node* pCur = pList; // let's start at the beginning of the list

	printf("--> "); // displays even if the list is empty

	while (pCur != NULL) // while we haven't reached the end of the list
	{
		// display the current Movie record
		printf("%d --> ", pCur->data);
		pCur = pCur->pNext; // go to the next node in sequence
	}

	putchar('\n');
}

/* ------------------------------ Task Functions ------------------------------ */

Node* mergeLists(Node* lists[], int numLists, int direction) {
	// base cases - no lists, no num lists given, and 0 direction
	if (lists == NULL || numLists <= 0 || direction == 0) return NULL;

	// this is the not most space-efficient, but I am going to set up copies
	// of the original lists that we can edit. I say this because I want to be
	// able to remove items as we go so it's easy to keep track of what
	// we have and haven't already moved. This is only an issue IF WE ALLOW DUPLICATES
	// in the list. THERE ARE BETTER WAYS TO DO THIS
	Node **listsCpy = (Node**)malloc(numLists * sizeof(Node*));
	if (listsCpy == NULL) return NULL;

	for (int i = 0; i < numLists; i++) {
		Node *pCur = lists[i];
		listsCpy[i] = NULL;  // null initially

		while (pCur != NULL) {
			insertBack(&listsCpy[i], pCur->data);
			pCur = pCur->pNext;
		}
	}

	// set up variables for algorithm
	Node *mergedList = NULL;  // merged list pointer
	int bestIdx, bestValue, lastVal;  // best value and index in lists for current loop

	// set last based on direction once
	if (direction < 0) {
		lastVal = INT_MAX;
	}
	else {
		lastVal = INT_MIN;
	}

	// loop to find best value, then push and pop
	while (anyNonNull(listsCpy, numLists)) {
		// set best based on direction
		if (direction < 0) {
			bestIdx = INT_MIN;
			bestValue = INT_MIN;
		}
		else {
			bestIdx = INT_MAX;
			bestValue = INT_MAX;
		}

		// loop through lists to find next best value list by list
		for (int i = 0; i < numLists; i++) {
			// skip index if no list left
			if (listsCpy[i] == NULL) continue;

			// loop through list to find best value for this list
			Node *pCur = listsCpy[i];

			while (pCur != NULL) {
				// check data against current best and last
				if (direction < 0) {  // descending
					if (pCur->data > bestValue && pCur->data <= lastVal) {
						bestIdx = i;
						bestValue = pCur->data;
					}
				}
				else {  // ascending
					if (pCur->data < bestValue && pCur->data >= lastVal) {
						bestIdx = i;
						bestValue = pCur->data;
					}
				}

				// walk along list
				pCur = pCur->pNext;
			}
		}

		// insert at back in merged list
		insertBack(&mergedList, bestValue);

		// remove from list we are taking from
		removeNode(&listsCpy[bestIdx], bestValue);

		// set new last val
		lastVal = bestValue;
	}

	return mergedList;
}

int anyNonNull(Node* lists[], int numLists) {
	for (int i = 0; i < numLists; i++)
		if (lists[i] != NULL) return 1;

	return 0;
}

int detectLoop(Node* list) {
	// based on Floyd's Tortoise and Hare algorithm

	Node *slow = list,
		 *fast = list;
	
	while (fast != NULL && fast->pNext != NULL) {
		// move slow by 1
		slow = slow->pNext;

		// move fast by 2
		fast = fast->pNext->pNext;

		// slow and fast will intersect (be equal) if there is a loop eventually
		if (slow == fast) return 1;
	}

	return 0;
}

Node* reverseList(Node** list) {
	// base case: empty list
	if (*list == NULL) return NULL;

	// base case: one node
	if ((*list)->pNext == NULL) return *list;
	
	// pointers for reversing
	Node *pPrev = NULL;
	Node *pCur = *list;
	Node* pNext = (*list)->pNext;

	// loop to reverse list
	while (pCur != NULL) {
		// swap pointers
		pCur->pNext = pPrev;

		// walk list
		pPrev = pCur;
		pCur = pNext;
		pNext = pNext->pNext;
	}

	// set new head
	*list = pPrev;

	return *list;
}
