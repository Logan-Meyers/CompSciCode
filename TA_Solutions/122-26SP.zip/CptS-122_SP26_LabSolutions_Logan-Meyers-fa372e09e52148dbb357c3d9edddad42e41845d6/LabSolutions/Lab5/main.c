#include "heapstring.h"
#include "list.h"

int main() {
	// str to heap
	demoStrToHeap();
	demoStrToHeapMem();
	
	// list functions
	demoMerge();
	demoLoop();

	return 0;
}