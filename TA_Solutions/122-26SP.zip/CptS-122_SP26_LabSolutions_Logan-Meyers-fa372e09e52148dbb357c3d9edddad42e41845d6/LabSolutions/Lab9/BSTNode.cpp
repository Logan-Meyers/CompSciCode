#include "BSTNode.hpp"

// other stream overloads
std::ostream& operator<<(std::ostream& lhs, const BSTNode& rhs) {
	lhs << rhs.getData();

	return lhs;
}