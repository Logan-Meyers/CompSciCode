#ifndef BST_H
#define BST_H

#include "BSTNode.hpp"

#include <vector>

using std::cout;
using std::endl;

class BST {

public:
	// rule of 3 and default (skipping some)
	BST() : mpRoot(nullptr) {}
	~BST() { destroyTree(); }

	// public-facing functions
	void insertNode(string toInsert);
	void inOrderTraversal() const;
	void preOrderTraversal() const;
	void postOrderTraversal() const;
	void inOrderIntoVector(std::vector<string>& result) const;
	bool isEmpty() const;

private:
	// root of tree
	BSTNode* mpRoot;

	// private recursive versions of the public functions above
	void insertNode(BSTNode* subtreeRoot, string toInsert);
	void inOrderTraversal(BSTNode* subtreeRoot) const;
	void preOrderTraversal(BSTNode* subtreeRoot) const;
	void postOrderTraversal(BSTNode* subtreeRoot) const;
	void inOrderIntoVector(BSTNode* subtreeRoot, std::vector<string>& result) const;

	// destroy
	void destroyTree();
	void destroyTree(BSTNode* subtree);
};

#endif