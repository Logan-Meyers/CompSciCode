#ifndef BSTNODE_H
#define BSTNODE_H

#include <iostream>

using std::string;

class BSTNode {

public:
	// default and rule of 3
	BSTNode() : mpLeft(nullptr), mpRight(nullptr), mData("") {}
	BSTNode(const BSTNode& copy) : mpLeft(nullptr), mpRight(nullptr), mData(copy.getData()) {}
	BSTNode(const string& value) : mpLeft(nullptr), mpRight(nullptr), mData(value) {}
	BSTNode& operator=(const BSTNode& rhs) {
		if (this == &rhs) return *this;
		
		this->mData = rhs.getData();
		this->mpLeft = rhs.getLeft();
		this->mpRight = rhs.getRight();

		return *this;
	}
	~BSTNode() {}

	// getters
	string getData() const { return mData; }
	BSTNode* getLeft() const { return mpLeft; }
	BSTNode* getRight() const { return mpRight; }

	// setters
	void setData(string newData) { mData = newData; }
	void setLeft(BSTNode* newLeft) { mpLeft = newLeft; }
	void setRight(BSTNode* newRight) { mpRight = newRight; }

	friend std::ostream& operator<<(std::ostream& lhs, const BSTNode& rhs);

private:
	BSTNode* mpLeft, * mpRight;
	string mData;
};

#endif