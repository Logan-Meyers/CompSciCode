#include "NameSort.hpp"

bool load_names(string*& names, int& num_names) {
	// first pass: determine number of names
	std::ifstream infile(NAME_FILE_IN);

	if (!infile.is_open()) return false;

	string line;
	while (std::getline(infile, line)) {
		if (line.size() > 1) num_names++;
	}

	// dynamically allocate enough room for that many names
	//if (names != nullptr) delete names;
	names = new string[num_names];

	// reset infile pointer to beginning
	infile.clear();
	infile.seekg(0, std::ios::beg);

	// second pass: actually read names into array
	int i = 0;
	while (std::getline(infile, line)) {
		names[i] = line;
		i++;
	}

	return true;
}
bool store_names(string*& names, int num_names) {
	std::ofstream outfile(NAME_FILE_OUT);

	if (!outfile.is_open()) return false;

	for (int i = 0; i < num_names; i++) {
		outfile << names[i] << std::endl;
	}

	return true;
}
bool sort_names(string*& names, int num_names) {
	BST nameTree;

	for (int i = 0; i < num_names; i++) {
		nameTree.insertNode(names[i]);
	}

	std::vector<string> sorted_names;  // prolly could have used vectors in the previous two funcs too for names
	nameTree.inOrderIntoVector(sorted_names);

	if (sorted_names.size() != num_names) return false;

	for (int i = 0; i < num_names; i++) {
		names[i] = sorted_names[i];
	}

	return true;
}

bool run_name_sort() {
	int num_names = 0;
	string* names;
	bool success = true;

	// thanks to Walker for showing me the &= trick with bools, useful for testing
	success &= load_names(names, num_names);
	success &= sort_names(names, num_names);
	success &= store_names(names, num_names);

	return success;
}