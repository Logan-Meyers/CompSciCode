#include "BST.hpp"
#include "NameSort.hpp"

int main() {
	cout << "BST Test in main:" << endl;

	BST t;

	string words[] = { "George", "Alazander", "Zillibob", "Qubert", "Logogogogog"};

	cout << "Names inserted in order: ";
	for (int i = 0; i < 5; i++) cout << words[i] << " ";
	cout << endl << "And after inserting into tree:" << endl;

	for (int i = 0; i < 5; i++)
		t.insertNode(words[i]);

	cout << "In order: ";
	t.inOrderTraversal();
	cout << "Pre order: ";
	t.preOrderTraversal();
	cout << "Post order: ";
	t.postOrderTraversal();

	bool success = run_name_sort();
	cout << "Name sort finished with success: " << (success ? "SUCCESS" : "FAILED") << endl;

	return 0;
}