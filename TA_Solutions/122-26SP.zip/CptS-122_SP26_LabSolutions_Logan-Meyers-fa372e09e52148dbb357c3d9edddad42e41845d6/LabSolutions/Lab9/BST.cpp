#include "BST.hpp"

// public-facing functions
void BST::insertNode(string toInsert) {
	// empty tree
	if (isEmpty()) {
		mpRoot = new BSTNode(toInsert);
	}
	// non-empty tree, recursive call
	else {
		insertNode(mpRoot, toInsert);
	}
}
void BST::inOrderTraversal() const {
	inOrderTraversal(mpRoot);
	cout << endl;
}
void BST::preOrderTraversal() const {
	preOrderTraversal(mpRoot);
	cout << endl;
}
void BST::postOrderTraversal() const {
	postOrderTraversal(mpRoot);
	cout << endl;
}
void BST::inOrderIntoVector(std::vector<string>& result) const {
	inOrderIntoVector(mpRoot, result);
}
bool BST::isEmpty() const {
	return mpRoot == nullptr;
}

// private recursive versions of the public functions above
void BST::insertNode(BSTNode* subtreeRoot, string toInsert) {
	if (subtreeRoot == nullptr) return;  // something wrong happened

	if (subtreeRoot->getData() == toInsert) return;  // duplicate

	// string should be on the left (less than current)
	if (toInsert < subtreeRoot->getData()) {
		// left empty, insert there
		if (subtreeRoot->getLeft() == nullptr) {
			subtreeRoot->setLeft(new BSTNode(toInsert));
		}
		// left not empty, recursive call left
		else {
			insertNode(subtreeRoot->getLeft(), toInsert);
		}
	}
	// string should be on the right (greater than current)
	else {
		// right empty, insert there
		if (subtreeRoot->getRight() == nullptr) {
			subtreeRoot->setRight(new BSTNode(toInsert));
		}
		// right not empty, recursive call right
		else {
			insertNode(subtreeRoot->getRight(), toInsert);
		}
	}
}
void BST::inOrderTraversal(BSTNode* subtreeRoot) const {
	// left, print, right
	if (subtreeRoot->getLeft()) inOrderTraversal(subtreeRoot->getLeft());
	cout << *subtreeRoot << " ";
	if (subtreeRoot->getRight()) inOrderTraversal(subtreeRoot->getRight());
}
void BST::preOrderTraversal(BSTNode* subtreeRoot) const {
	// print, left, right
	cout << *subtreeRoot << " ";
	if (subtreeRoot->getLeft()) inOrderTraversal(subtreeRoot->getLeft());
	if (subtreeRoot->getRight()) inOrderTraversal(subtreeRoot->getRight());
}
void BST::postOrderTraversal(BSTNode* subtreeRoot) const {
	// left, right, print
	if (subtreeRoot->getLeft()) inOrderTraversal(subtreeRoot->getLeft());
	if (subtreeRoot->getRight()) inOrderTraversal(subtreeRoot->getRight());
	cout << *subtreeRoot << " ";
}
void BST::inOrderIntoVector(BSTNode* subtreeRoot, std::vector<string>& result) const {
	// left, print, right
	if (subtreeRoot->getLeft()) inOrderIntoVector(subtreeRoot->getLeft(), result);
	result.push_back(subtreeRoot->getData());
	if (subtreeRoot->getRight()) inOrderIntoVector(subtreeRoot->getRight(), result);
}

// destroy
void BST::destroyTree() {
	destroyTree(mpRoot);
}
void BST::destroyTree(BSTNode* subtree) {
	if (subtree == nullptr) return;

	// post order delete
	destroyTree(subtree->getLeft());
	destroyTree(subtree->getRight());
	delete subtree;
}