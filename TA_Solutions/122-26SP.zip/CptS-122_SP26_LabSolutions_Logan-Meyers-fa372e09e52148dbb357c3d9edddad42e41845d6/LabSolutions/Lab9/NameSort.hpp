#ifndef NAMESORT_H
#define NAMESORT_H

#include "BST.hpp"
#include <fstream>
#include <istream>
#include <string>  // for getline

#define NAME_FILE_IN "names.txt"
#define NAME_FILE_OUT "names_sorted.txt"

bool load_names(string*& names);
bool store_names(string*& names);
bool sort_names(string*& names);
bool run_name_sort();

#endif