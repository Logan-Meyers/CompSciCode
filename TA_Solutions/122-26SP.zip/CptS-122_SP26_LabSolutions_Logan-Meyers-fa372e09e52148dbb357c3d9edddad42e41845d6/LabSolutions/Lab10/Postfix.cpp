#include "Postfix.hpp"

// Postfix expressions can be tested at https://www.calcont.in/Calculator/Postfix_calculator/
// NOTE: a '=' is required at the end of each expression for this function to return properly
bool evalPostfix(string expression, double &out) {
	// convert expression to a stream for easy reading
	istringstream exp(expression);
	
	// 1. make stack for values
	Stack<double> s;

	// 2. return false (fail) if no more chars left in string
readNextChar:
	if (exp.eof()) return false;

	// 3. read next char into c
	char c;
	exp >> c;

	// 4. c '=' case
	if (c == '=') {
		// 4.1. s empty, malformed
		// 4.2. s more than one element, malformed
		if (s.isEmpty() || s.getSize() > 1)
			return false;

		// 4.3. get e from top of stack and return it
		double e = 0.0;
		s.pop(e);
		out = e;
		return true;
	}

	// 5. c digit case
	if (isdigit(c)) {
		// push c onto s
		double cAsDouble = (double)(c - '0');
		s.push(cAsDouble);  // can't just pass in conversion because it needs to be referencable

		// goto step 2
		goto readNextChar;
	}

	// 6. binary operator case
	if (c == '+' || c == '-' || c == '/' || c == '*') {
		// 6.1. S not enough (at least 2) elements, malformed
		if (s.getSize() < 2) return false;

		// 6.2. pop two elements off of s
		double s1, s2;
		s.pop(s2);
		s.pop(s1);

		// 6.3. apply operator and call it v
		double v;

		switch (c) {
			case '+':
				v = s1 + s2;
				break;
			case '-':
				v = s1 - s2;
				break;
			case '/':
				v = s1 / s2;
				break;
			case '*':
				v = s1 * s2;
				break;
			default:
				return false;
		}

		// 6.4. push v onto s
		s.push(v);

		// 6.5. goto step 2
		goto readNextChar;

	}

	// not mentioned, but defensive case- unsupported
	return false;
}

// honestly, the best place to find an example answer is at:
// https://www.geeksforgeeks.org/dsa/convert-infix-expression-to-postfix-expression/
// Additionally, take a look at Andy's link to the explanation and follow it:
// https://eecs.wsu.edu/~aofallon/cpts122/labs/Infix2Postfix.pdf
// For the sake of time (and my sanity, currently), I have not implemented this.
//     However, I encourage you to take a look at the instructions and try it out
//     for yourself! If I run into enough time I may update this Lab solution with
//     a complete code example.

// string infixToPostfix(string& s);