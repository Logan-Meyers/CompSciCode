#ifndef POSTFIX_H
#define POSTFIX_H

#include "Stack.hpp"
#include <sstream>  // for string streams (istringstream)
#include <cctype>  // for isdigit

using std::istringstream;
using std::isdigit;
using std::string;

bool evalPostfix(string expression, double& out);

//string infixToPostfix(string& s);

#endif