# Big O Time Complexity for various Algorithms!

In **arrays** vs **linked lists**...

<ol type="a">
  <li><b>Delete last:</b> Array</li>
  <li><b>Delete first:</b> Linked List</li>
  <li><b>Delete in general:</b> Linked List</li>
  <li><b>Insert end:</b> Array</li>
  <li><b>Insert front:</b> Linked List</li>
  <li><b>Insert in general:</b> Linked List</li>
  <li><b>Access in general:</b> Array</li>
</ol>