// This example illustrates how to define a Stack class template.

#include "TestStack.hpp"
#include "Postfix.hpp"

using std::string;

#include <vector>

void testTemplateStack();
void testPostfixEval();
void testInfixToPostfix();

union A {
	int x;
	char y;
};

int main(void)
{
	testTemplateStack();
	testPostfixEval();
	testInfixToPostfix();

	Stack<A> s;

	A a = { 5 };
	A b = { '5' };

	s.push(a);
	s.push(b);

	return 0;
}

void testTemplateStack() {
	int item1 = -89, item2 = 104;

	//	vector<int> my_vector; // vector<> is from the Standard Template Library (STL)

	TestStack<int> tester;

	tester.Test(item1, item2);
}

void testPostfixEval() {
	std::vector<string> exprs = { "6 2 + 5 * 8 4 / - =", "5 6 2 * + 9 / =", "4 5 / 6 8 * - =", "5 + ="};
	std::vector<double> answers = { 38, 1.889, -47.2, 0 };
	std::vector<bool> successes = { true, true, true, false };

	cout << endl << "-- Testing postfix evaluation --" << endl;
	
	// NOTE: you'll see the second one technically passes, but fails since
	//		 answers do not quite match due to rounding

	// NOTE: fourth one should also fail due to being malformed

	for (int i = 0; i < exprs.size(); i++) {
		double res = 0;
		bool success = evalPostfix(exprs[i], res);

		success &= (res == answers[i]);
		success &= (success == successes[i]);

		cout << "Test #" << i << ": "
			<< "(" << exprs[i] << ") "
			<< (success ? "PASSED" : "FAILED")
			<< " with answer " << res
			<< "; should be " << answers[i] << "." << endl;
	}
}

void testInfixToPostfix() {
	std::vector<string> infix = { "3 + 5 + 7", "3 * 15 / 5" };
	std::vector<string> postfix = { "35+7+", "39*3/" };
	
	cout << endl << "-- Testing infix to postfix conversion --" << endl;

	for (int i = 0; i < infix.size(); i++) {
		string res;
		//string res = infixToPostfix(infix[i]);

		bool success = res == postfix[i];

		cout << "Test #" << i << ": "
			<< "(" << infix[i] << ") "
			<< (success ? "PASSED " : "FAILED ")
			<< "convering to (" << postfix[i] << ")";

		if (!success)
			cout << "; got (" << res << ")";
		
		cout << endl;
	}
}