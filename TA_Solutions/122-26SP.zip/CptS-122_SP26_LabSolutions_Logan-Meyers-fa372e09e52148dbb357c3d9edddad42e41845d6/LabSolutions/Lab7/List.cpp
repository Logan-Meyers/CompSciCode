#include "List.hpp"

// default constructor; will always set mpHead to NULL or nullptr
List::List()
{
	mpHead = nullptr;
}

// copy constructor - implicitly invoked copying a List object during construction of 
// another List object, or when a List object is passed-by-value - must perform a deep copy, 
// which means create new memory for each node copied!
List::List(const List& copyList)
{
	// if no list to copy from, set head to null and stop
	if (copyList.mpHead == nullptr) {
		this->mpHead = nullptr;
		return;
	}

	// perform deep copy by making space for new nodes and adding to our list
	// as we go along copy list

	// copy first node
	this->mpHead = new ListNode(copyList.mpHead->getData());
	ListNode* cur = this->mpHead;
	ListNode *curcpy = copyList.mpHead->getNextPtr();

	// copy each node left
	while (curcpy) {
		cur->setNextPtr(new ListNode(curcpy->getData()));
		cur = cur->getNextPtr();
		curcpy = curcpy->getNextPtr();
	}
}

List::~List()                   // destructor - implicitly invoked when a List object leaves scope
{
	cout << "Inside List's destructor! Freeing each ListNode in the List!" << endl;
	destroyList();
}

// this function must allocate new memory for each of the nodes in rhs to construct "this" object
List& List::operator= (const List& rhs) // overloaded assignment operator - must perform a deep copy
{
	// you must use a loop, which visits each of the nodes in List rhs, and assign the data to the new nodes
	// How to use new operator? ListNode *pMem = new ListNode; new is similar to the results of using malloc ()

	// first, clear list
	destroyList();

	// then, do same process as in the copy constructor

	// if no list to copy from, set head to null and stop
	if (rhs.mpHead == nullptr) {
		this->mpHead = nullptr;
		return *this;
	}

	// perform deep copy by making space for new nodes and adding to our list
	// as we go along copy list

	// copy first node
	this->mpHead = new ListNode(rhs.mpHead->getData());
	ListNode* cur = this->mpHead;
	ListNode* curcpy = rhs.mpHead->getNextPtr();

	// copy each node left
	while (curcpy) {
		cur->setNextPtr(new ListNode(curcpy->getData()));
		cur = cur->getNextPtr();
		curcpy = curcpy->getNextPtr();
	}

	return (*this);
}

// getter
ListNode* List::getHeadPtr() const     // returns a copy of the address stored in mpHead
{
	return mpHead;
}

// setter
void List::setHeadPtr(ListNode* const pNewHead) // modifies mpHead
{
	mpHead = pNewHead;
}

// This function creates a new ListNode on the heap, and uses the ListNode constructor to initialize the node!
bool List::insertAtFront(const int newData)     // inserts newData at the beginning or front of the list
{
	ListNode* pMem = makeNode(newData);
	bool success = false;                   // C++ has built in bool types - false, true

	if (pMem != nullptr)
	{
		success = true; // allocated memory successfully
		// pMem is pointing to a ListNode object, but a List object does not have direct access to it; must use a setter!
		pMem->setNextPtr(mpHead);
		mpHead = pMem;
	}

	return success;
}

// insert newData in ascending order
bool List::insertInOrder(const int newData)
{
	bool success = false;

	// make space for node
	ListNode *pMem = new ListNode(newData);

	if (pMem != nullptr) success = true;
	else return success;

	// case 1: insert to beginning of list
	if (isEmpty() || newData < this->mpHead->getData()) {
		insertAtFront(newData);
		return success;
	}

	// case 2: find spot elsewhere including end
	ListNode* pCur = this->mpHead;

	while (pCur->getNextPtr() != nullptr && newData > pCur->getNextPtr()->getData()) {
		pCur = pCur->getNextPtr();
	}

	// insert
	pMem->setNextPtr(pCur->getNextPtr());
	pCur->setNextPtr(pMem);

	return success;
}

// inserts newData at the end of the list
bool List::insertAtEnd(const int newData)
{
	bool success = false;

	// create space for node
	ListNode* pMem = new ListNode(newData);
	if (pMem != nullptr) success = 1;
	else return success;

	// case 1: list empty, insert at front
	if (this->mpHead == nullptr) {
		insertAtFront(newData);
		return success;
	}

	// case 2: somewhere else in list; find end of list
	ListNode *pCur = this->mpHead;

	while (pCur->getNextPtr() != nullptr) {
		pCur = pCur->getNextPtr();
	}

	// insert
	pCur->setNextPtr(pMem);

	return success;
}

// determines if the list is empty;  
// returns true if the list is empty; false otherwise
bool List::isEmpty()
{
	return (mpHead == nullptr);
}

// deletes the node at the front of the list and returns a copy of the data
// precondition: list must not be empty
int List::deleteAtFront()
{
	int data = 0;

	// tmp pointer to front
	ListNode* tmp = this->mpHead;
	
	// get data to delete
	data = tmp->getData();

	// move head of list
	this->mpHead = this->mpHead->getNextPtr();

	// delete tmp node
	delete tmp;

	return data;
}

// deletes the node with data == searchValue;
// returns true if the value was found; false otherwise
// precondition: list must not be empty
bool List::deleteNode(const int searchValue)
{
	bool success = false;

	// case 1: item to delete is at front; reuse code we already have
	if (this->mpHead->getData() == searchValue) {
		deleteAtFront();
		return true;
	}

	// case 2: somewhere else in the list
	ListNode* pCur = this->mpHead;

	// find node in next
	while (pCur->getNextPtr() != nullptr && pCur->getNextPtr()->getData() != searchValue) {
		pCur = pCur->getNextPtr();
	}

	// fail on no node found
	if (pCur == nullptr) return false;

	// else, delete node
	ListNode* tmp = pCur->getNextPtr();
	pCur->setNextPtr(pCur->getNextPtr()->getNextPtr());

	delete tmp;

	return success;
}

// deletes the node at the end of the list and returns a copy of the data
// precondition: list must not be empty
int List::deleteAtEnd()
{
	int data = 0;

	// case 1: one node in list
	if (this->mpHead->getNextPtr() == nullptr) {
		data = this->mpHead->getData();
		delete this->mpHead;
		this->mpHead = nullptr;
	}
	// case 2: somewhere else in list
	else {
		// find node before last
		ListNode* pCur = this->mpHead;
		while (pCur->getNextPtr()->getNextPtr() != nullptr)
			pCur = pCur->getNextPtr();

		// delete node and fix dangling ptr
		delete pCur->getNextPtr();
		pCur->setNextPtr(nullptr);
	}

	return data;
}

// visits each node, print the node's data
void List::printList()
{
	ListNode* pCur = mpHead;

	while (pCur != nullptr)
	{
		cout << pCur->getData() << endl;
		pCur = pCur->getNextPtr();
	}
}


//////////// private member functions! //////////////

// allocates memory for a Listnode; initializes the memory with newData
ListNode* List::makeNode(const int newData)    // will only call within insert functions
{
	ListNode* pMem = new ListNode(newData);  // ListNode constructor is invoked!

	return pMem;
}

// we created this function so that we could use recursion to delete the nodes!
void List::destroyListHelper(ListNode* const pMem)
{
	if (pMem != nullptr)
	{
		destroyListHelper(pMem->getNextPtr());
		delete pMem;    // delete from the back of list to the front!
	}
}

// deletes each node to free memory; will call in the destructor
void List::destroyList()
{
	destroyListHelper(mpHead);
}