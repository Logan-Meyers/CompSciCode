#include "ListApp.hpp"

int main(void)
{
	// Start with debugging this project! "Step Into" each statement to answer the questions!
	// Question 1: what function is called in the statement below?
	// A: ListNode's default constructor
	ListNode n1;
	// Question 2: what function is called in the statement below?
	// A: ListNode's default constructor
	ListNode n2(42); // shallow or deep copy? deep copy of '42'
	// Question 3: what function is called in the statement below?
	// A: ListNode's copy constructor
	ListNode n3(n2); // shallow or deep copy? shallow copy of 'n2'
	// Question 4: what function is called in the statement below?
	// A: ListNode's copy constructor
	ListNode n4 = n3; // shallow or deep copy? shallow copy of 'n2'

	ListNode n5;
	// Question 5: what function/operator is called in the statement below?
	// A: the compiler-generated copy assignment constructor, which is likely a shallow copy.
	n5 = n4; // did we explicitly implement this function/operator? no

	// Question 6: what function is called in the statement below?
	// A: List's default constructor
	List l1;
	l1.insertAtFront(4);
	l1.insertAtFront(2);
	l1.insertAtFront(1);
	// make sure that you finish implementing the copy constructor for the List object before you try to 
	// execute the next statement!
	// Question 7: what function is called in the statement below? What would happen if we did not 
	//             explicitly implement the function? Would the compiler generated one be good enough?
	// A: List's copy constructor
	List l2 = l1; // shallow or deep copy? deep
	// Question 8: what would happen if a shallow copy constructor is used, instead of a deep copy constructor, 
	//             when the destructor for each list object is implicily invoked? l2 and l1 would have the same
	//             address stored in the head pointer, and thus, one of the lists would be freed and when the other went
	//             out of scope, the destructor would try to access already freed memory (a dangling pointer situation)!


	List l3;

	// inserting some items to check deep copy works
	l3.insertAtFront(2);
	l3.insertAtFront(1);
	// make sure that you finish implementing the overloaded assignment for the List object before you try to 
	// execute the next statement!
	// Question 9: what function is called in the statement below? What would happen if we did not 
	//             explicitly implement the function? Would the compiler generated one be good enough?
	l3 = l2; // shallow or deep copy? deep
	// Question 10: what would happen if a shallow copy assignment is used, instead of a deep copy assignment, 
	//              when the destructor for each list object is implicily invoked? l3 and l2 would have the same
	//              address stored in the head pointer, and thus, one of the lists would be freed and when the other went
	//              out of scope, the destructor would try to access already freed memory (a dangling pointer situation)!

	// Question 11: how does the List destructor free up the nodes? You will need to visit "List.cpp" to answer this question!
	// A: The List destructor is a recursive function which visits each node and deletes from the back to the beginning
	//    due to it being recursive.

	/*
		What's the difference between shallow and deep copy?

		Think about what the words 'shallow' and 'deep' mean-
			shallow is more 'lazy'
			deep is more 'in-depth'

		What does this mean?

		Think of a shallow copy as simply making a reference to something:
			this could be like using reference (pass-by-reference) variables (making another name for the same thing)
			or this could be like making two pointers that have the same direct value (point to the same thing)

		Think of a deep copy as duplicating something.

		Let's look at a code example:
			```
			int n1 = 5;
			int n2 = n1;
			n2 = 6;
			```

			As we know, n1 is 5, n2 takes on the value of 5, but changing the value of n2 doesn't change n1;
			therefore, n1 = 5 and n2 = 6.
			They are different objects, and what you do to one doesn't affect the other.
			This is a deep copy.

		Another example:
			```
			int* n1 = new int(5);
			int* n2 = n1;
			*n2 = 6;
			```

			As we have figured out through the first half of this class, changing the indirect value of
			n2 would also change the indirect value of n1, since they're pointing to the same object.
			So, *n1 = 6 and *n2 = 6.
			This is a shallow copy- like making a referene to the same thing.

		One last example:
			```
			int* n1 = new int(5);
			int* n2 = new int(*n1);
			*n2 = 6;
			```

			We have the same scenario as before, but now we're making a deep copy.
			We're making a deep copy because we're making a new object but with the same value of the
			one we're trying to copy.

		So when it comes to all of the base types in C/C++ (like int, double, char, etc), making a copy
			is generally a deep copy because there's no dynamic memory involved.
		But when it comes to pointers and dynamic memory, simply making a copy of the direct values will
			cause issues when you want to make true copies and be able to duplicate them.
		That's where deep copies come in, because deep copies are all about making a duplicate (new object,
			same value(s)) of what you want to copy.
		Take for example, a linked list:
			- a shallow copy of a linked list is just copying the head pointer.
			- a deep copy is making all new nodes with the same values and in the same order as the original.
	*/

	// testing most cases for the methods we just implemented for List
	List l4;
	l4.insertInOrder(10);
	l4.insertInOrder(3);
	l4.insertInOrder(7);
	l4.insertInOrder(5);
	l4.insertInOrder(1);
	l4.printList();
	l4.deleteAtFront();
	l4.deleteNode(7);
	l4.deleteNode(3);
	l4.deleteAtEnd();
	l4.deleteAtEnd();

	ListApp app;

	app.runApp();

	return 0;
}