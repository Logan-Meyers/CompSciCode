#ifndef PERSON_H
#define PERSON_H

#include <iostream>

using std::string;
using std::ostream;
using std::istream;
using std::cout;
using std::endl;

class Person {

public:
	Person(string name = "", string gender = "NA", int age = 0, int height = 0);
	Person(Person& copy);
	~Person();

	Person& operator=(Person& rhs);

	friend ostream& operator<<(ostream& lhs, const Person& rhs);
	friend istream& operator>>(istream& lhs, Person& rhs);

	// getters
	string getName();
	string getGender();
	int getAge();
	double getHeight();

	// setters
	void setName(string name);
	void setGender(string gender);
	void setAge(int age);
	void setHeight(int height_cm);

	// Make TestPerson a friend so it can access the private data members
	friend class TestPerson;

	virtual void print() {}

protected:
	string name, gender;
	int age;
	double height;  // cm because easy
};

#endif