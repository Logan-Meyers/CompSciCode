#include "Person.hpp"

Person::Person(string name, string gender, int age, int height) {
	this->name = name;
	this->gender = gender;
	this->age = age;
	this->height = height;

	cout << "Created a person!" << endl;
}
Person::Person(Person& copy) {
	if (&copy != this) {
		this->name = copy.name;
		this->gender = copy.gender;
		this->age = copy.age;
		this->height = copy.height;
	}
}
Person::~Person() {}

Person& Person::operator=(Person& rhs) {
	if (&rhs != this) {
		this->name = rhs.name;
		this->gender = rhs.gender;
		this->age = rhs.age;
		this->height = rhs.height;
	}

	return *this;
}

ostream& operator<<(ostream& lhs, const Person& rhs) {
	lhs << rhs.name << ": " << rhs.gender << ", " << rhs.age << "y, " << rhs.height << " cm" << endl;

	return lhs;
}
istream& operator>>(istream& lhs, Person& rhs) {
	// NOT DEFENSIVE PROGRAMMING
	// could use more guards

	lhs >> rhs.name;
	lhs >> rhs.gender;
	lhs >> rhs.age;
	lhs >> rhs.height;

	return lhs;
}

// getters
string Person::getName() {
	return this->name;
}
string Person::getGender() {
	return this->gender;
}
int Person::getAge() {
	return this->age;
}
double Person::getHeight() {
	return this->height;
}

// setters
void Person::setName(string name) {
	this->name = name;
}
void Person::setGender(string gender) {
	this->gender = gender;
}
void Person::setAge(int age) {
	this->age = age;
}
void Person::setHeight(int height_cm) {
	this->height = height_cm;
}