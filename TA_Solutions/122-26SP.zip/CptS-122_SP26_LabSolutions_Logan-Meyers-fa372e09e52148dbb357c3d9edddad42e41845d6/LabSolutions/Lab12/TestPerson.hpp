#ifndef TEST_PERSON_H
#define TEST_PERSON_H

#include "Person.hpp"
#include <sstream>

static class TestPerson : public Person {

public:
	void testConstructor();
	void testCopyConstructor();
	void testCopyAssignmentConstructor();
	void testInsertion();
	void testExtraction();
	void testSetters();
	void testGetters();
	void testAll();

private:
};

#endif