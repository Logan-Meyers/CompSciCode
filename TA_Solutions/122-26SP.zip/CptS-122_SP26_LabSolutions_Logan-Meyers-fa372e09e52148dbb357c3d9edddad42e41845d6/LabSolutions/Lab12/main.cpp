// Lab 12 Solution

/*
Task 6 PROMPT:
	Hey Claude! I'm working on an assignment in C++ and I'm working on learning inheritance. Here are the instructions for the tasks:

	Task 1: Create a base class called Person, which has private data members for a name, age, gender, and height. Implement a constructor, copy constructor, destructor, overloaded assignment operator, overloaded stream insertion and extraction operators, and getters and setters. See Task 2 for testing this class.
	Task 2: Create a derived class called TestPerson, which publically inherits from class Person. Create test methods for each method in class Person. Remember these functions should not accept any parameters or return any values. However, they should print messages for “test case passed” or “test case failed”.
	Task 3: Modify your class Person so that the data members are protected instead of private. How does this affect the tests cases that you created in Task 2?
	Task 4: Create a derived class called Student, which publically inherits from class Person. Add three private data members to class Student. These include an array of struct Course, the number of courses taken, and the total number of credits. The struct Course should contain a string for course name, credits assigned to course, and current grade in course. Implement appropriate constructors, overloaded operators, and setters and getters for this class. Also, implement methods for computing total credits taken and current GPA. How would your implementation change if you decided to define a class Course instead of struct Course?
	Task 5: Create a derived class called Teacher, which publically inherits from class Person. Add three private data members to class Teacher. These include an array of struct Course, the number of courses taken, and the total number of credits. The struct Course should contain a string for course name, credits assigned to course, and average grade of students’ in course. Implement appropriate constructors, overloaded operators, and setters and getters for this class. Also, implement methods for computing total credits taught and average grades of students across the courses taught. How would your implementation change if you decided to derive class Teacher from class Student instead of class Person?
	Task 6: Create an application, which allows students to register for classes taught by a particular teacher.

	Please **only do task 6**, so that I can implement the first 5 and make them work with the application. There must be a simple REPL with a handful of menu options, and include a test class/function/menu option.
AI Model:
	
	Claude:Sonnet 4.5
*/

// main.cpp
#include <iostream>
#include <string>
#include <vector>

#include "TestPerson.hpp";
#include "Teacher.hpp"
#include "Student.hpp"

using namespace std;

// Forward declarations (you'll implement these)
class Person;
class Student;
class Teacher;
class Course;

class RegistrationSystem {
private:
    vector<Student*> students;
    vector<Teacher*> teachers;

public:
    void addStudent(Student* s) { students.push_back(s); }
    void addTeacher(Teacher* t) { teachers.push_back(t); }

    void displayStudents() {
        cout << "\n=== Students ===\n";
        for (size_t i = 0; i < students.size(); i++) {
            cout << i << ". ";
            // You'll need to implement operator<< for Student
            //cout << *students[i] << endl;
        }
    }

    void displayTeachers() {
        cout << "\n=== Teachers ===\n";
        for (size_t i = 0; i < teachers.size(); i++) {
            cout << i << ". ";
            //cout << *teachers[i] << endl;
        }
    }

    void registerStudentForCourse() {
        if (students.empty() || teachers.empty()) {
            cout << "Need at least one student and one teacher.\n";
            return;
        }

        displayStudents();
        cout << "Select student (index): ";
        int studentIdx;
        cin >> studentIdx;

        displayTeachers();
        cout << "Select teacher (index): ";
        int teacherIdx;
        cin >> teacherIdx;

        cout << "Enter course name: ";
        string courseName;
        cin.ignore();
        getline(cin, courseName);

        cout << "Enter credits: ";
        int credits;
        cin >> credits;

        // You'll need to implement addCourse() in Student class
        // students[studentIdx]->addCourse(courseName, credits, teachers[teacherIdx]);
        cout << "Student registered for course!\n";
    }

    void runTests() {
        cout << "\n=== Running Tests ===\n";
        
        TestPerson t;
        t.testAll();

        cout << "Tests completed.\n";
    }
};

int main() {
    //RegistrationSystem sys;

    //while (true) {
    //    cout << "\n=== Course Registration System ===\n";
    //    cout << "1. Add Student\n";
    //    cout << "2. Add Teacher\n";
    //    cout << "3. Register Student for Course\n";
    //    cout << "4. Display Students\n";
    //    cout << "5. Display Teachers\n";
    //    cout << "6. Run Tests\n";
    //    cout << "0. Exit\n";
    //    cout << "Choice: ";

    //    int choice;
    //    cin >> choice;

    //    if (choice == 0) break;

    //    switch (choice) {
    //    case 1: {
    //        // You'll create Student constructor
    //        // Student* s = new Student(...);
    //        // sys.addStudent(s);
    //        cout << "Student creation - implement this\n";
    //        break;
    //    }
    //    case 2: {
    //        // Teacher* t = new Teacher(...);
    //        // sys.addTeacher(t);
    //        cout << "Teacher creation - implement this\n";
    //        break;
    //    }
    //    case 3:
    //        sys.registerStudentForCourse();
    //        break;
    //    case 4:
    //        sys.displayStudents();
    //        break;
    //    case 5:
    //        sys.displayTeachers();
    //        break;
    //    case 6:
    //        sys.runTests();
    //        break;
    //    default:
    //        cout << "Invalid choice.\n";
    //    }
    //}

    //Person a("Bob", "Male", 20, 173);

    cout << endl << endl;

    Teacher b("Andy", "Male", 25, 164);

    b.print();

    cout << endl << endl;

    Student c("Blaze", "Female", 23, 182);

    c.print();

    cout << endl << endl;

    std::vector<Person> people;

    people.push_back(b);
    people.push_back(c);

    for (auto it = people.begin(); it != people.end(); ++it) {
        (*it).print();
    }

    return 0;
}
