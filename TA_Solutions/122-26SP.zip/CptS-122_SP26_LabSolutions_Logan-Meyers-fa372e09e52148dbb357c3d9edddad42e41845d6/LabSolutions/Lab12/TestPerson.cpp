#include "TestPerson.hpp"

void TestPerson::testConstructor() {
	Person a("Bob", "Male", 20, 173);

	if (a.name == "Bob" && a.gender == "Male" && a.age == 20 && a.height == 173) {
		cout << "Test Constructor passed!" << endl;
	}
	else {
		cout << "Test Constructor failed!" << endl;
	}
}
void TestPerson::testCopyConstructor() {
	Person b("Jenny", "Female", 21, 104);

	Person a(b);

	if (a.name == "Jenny" && a.gender == "Female" && a.age == 21 && a.height == 104) {
		cout << "Test Copy Constructor passed!" << endl;
	}
	else {
		cout << "Test Copy Constructor failed!" << endl;
	}
}
void TestPerson::testCopyAssignmentConstructor() {
	Person a("Bob", "Male", 20, 173);
	Person b("Jenny", "Female", 21, 104);

	a = b;

	if (a.name == "Jenny" && a.gender == "Female" && a.age == 21 && a.height == 104) {
		cout << "Test Copy Constructor passed!" << endl;
	}
	else {
		cout << "Test Copy Constructor failed!" << endl;
	}

}
void TestPerson::testInsertion() {
	std::ostringstream oss("");
	std::ostringstream comp("Perry: Platypus, 5y, 61 cm\n");

	Person a("Perry", "Platypus", 5, 61);

	oss << a;

	if (oss.str() == comp.str()) {
		cout << "Test Insertion passed!" << endl;
	}
	else {
		cout << "Test Insertion failed!" << endl;
	}
}
void TestPerson::testExtraction() {
	std::istringstream iss("Perry Platypus 5 61");
	
	Person a;

	iss >> a;

	if (a.name == "Perry" && a.gender == "Platypus" && a.age == 5 && a.height == 61) {
		cout << "Test Extraction passed!" << endl;
	}
	else {
		cout << "Test Extraction failed!" << endl;
	}
}
void TestPerson::testSetters() {
	Person a;

	a.setName("Quincy");
	a.setGender("Female");
	a.setAge(19);
	a.setHeight(216);

	if (a.name == "Quincy" && a.gender == "Female" && a.age == 19 && a.height == 216) {
		cout << "Test Setters passed!" << endl;
	}
	else {
		cout << "Test Setters failed!" << endl;
	}
}
void TestPerson::testGetters() {
	Person a;

	a.setName("Quincy");
	a.setGender("Female");
	a.setAge(19);
	a.setHeight(216);

	if (a.getName() == "Quincy" && a.getGender() == "Female" && a.getAge() == 19 && a.getHeight() == 216) {
		cout << "Test Getters passed!" << endl;
	}
	else {
		cout << "Test Getters failed!" << endl;
	}
}

void TestPerson::testAll() {
	testConstructor();
	testCopyConstructor();
	testCopyAssignmentConstructor();
	testInsertion();
	testExtraction();
	testSetters();
	testGetters();
}
