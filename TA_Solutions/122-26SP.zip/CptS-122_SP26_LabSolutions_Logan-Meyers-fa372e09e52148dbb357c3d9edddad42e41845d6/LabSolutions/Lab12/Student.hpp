#ifndef STUDENT_H
#define STUDENT_H

#include "Person.hpp"

class Student : public Person {

public:
	Student(string name = "", string gender = "NA", int age = 0, int height = 0)
		: Person(name, gender, age, height)
	{
		cout << "Created a student!" << endl;
		numClasses = 0;
		numCredits = 0;
	}

	void print() override {
		cout << "Student: " << this->name;
	}

private:
	typedef struct course {
		string courseName = "";
		int credits = 0;
		double avgGrade = 0;
	} Course;

	Course courses[6];
	int numClasses, numCredits;
};

#endif