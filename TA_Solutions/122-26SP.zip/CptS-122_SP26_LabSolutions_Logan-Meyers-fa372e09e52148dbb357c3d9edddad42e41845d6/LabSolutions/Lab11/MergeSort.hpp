#ifndef MERGE_SORT_H
#define MERGE_SORT_H

#include <iostream>
#include <string>
#include <vector>

using std::cout;
using std::endl;
using std::string;
using std::vector;

// "private" function which accepts the vector AND the start/end points
template<class T>
void mergeSort(vector<T>& toSort, int startIdx, int endIdx) {
	// base case: one item or out of range: stop
	if (startIdx >= endIdx) return;

	// find mid point (floor int division)
	int midIdx = startIdx + ((endIdx - startIdx) / 2);

	// resursive calls - work on left and right sections
	mergeSort(toSort, startIdx, midIdx);
	mergeSort(toSort, midIdx + 1, endIdx);

	// create temp versions of the left and right halves given (a snapshot before we merge)
	vector<T> left(toSort.begin() + startIdx, toSort.begin() + midIdx + 1);
	vector<T> right(toSort.begin() + midIdx + 1, toSort.begin() + endIdx + 1);

	// merge into original (toSort) here
	size_t i = 0;  // index in left
	size_t j = 0;  // index in right
	size_t k = startIdx;  // index in toSort

	// insert most of the left and right, until we run out of either
	while (i < left.size() && j < right.size()) {
		// left smaller? insert (replace toSort with) that
		if (left[i] < right[j])
			toSort[k] = left[i++];

		// right smaller? insert (replace toSort with) that
		else
			toSort[k] = right[j++];

		// increment k either way
		k++;
	}

	// clean up step: insert from left or right (only one will happen) until no more
	while (i < left.size()) toSort[k++] = left[i++];
	while (j < right.size()) toSort[k++] = right[j++];
}

// "public" function which accepts just the vector
template <class T>
void mergeSort(vector<T>& toSort) {
	mergeSort(toSort, 0, toSort.size() - 1);
}

// print a vector nicely
template <class T>
void printVec(vector<T>& vec, string name = "") {
	if (name != "") cout << name << ": ";

	for (int i = 0; i < vec.size(); i++) {
		cout << vec[i];
		if (i < vec.size() - 1) cout << ", ";
	}

	cout << endl;
}

void testMergeSort();

#endif