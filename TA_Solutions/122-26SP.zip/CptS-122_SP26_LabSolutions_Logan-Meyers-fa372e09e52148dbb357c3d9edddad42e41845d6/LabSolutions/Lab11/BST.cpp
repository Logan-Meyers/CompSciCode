#include "BST.hpp"

void testBSTDeleteNode() {
	BST<int> tree;

	tree.insert(50);
	tree.insert(30);
	tree.insert(20);
	tree.insert(40);
	tree.insert(70);
	tree.insert(60);
	tree.insert(80);
	
	cout << "----- TESTING BST DELETE NODE -----" << endl;

	cout << "Before (in order print): " << tree << endl;

	tree.deleteNode(50);

	cout << "After deleting 50: " << tree << endl;

	tree.deleteNode(20);

	cout << "After deleting 20: " << tree << endl;
	
	tree.deleteNode(1000);

	cout << "After deleting 1000 (doesn't exist): " << tree << endl;

	cout << endl;
}
