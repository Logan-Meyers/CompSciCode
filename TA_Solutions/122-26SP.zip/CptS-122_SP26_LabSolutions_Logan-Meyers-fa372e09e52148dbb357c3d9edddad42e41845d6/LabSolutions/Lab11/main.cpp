// Lab 11 solution
// TA: Logan Meyers

#include "MergeSort.hpp"
#include "BST.hpp"

int main() {
	testMergeSort();
	testBSTDeleteNode();

	return 0;
}
