#ifndef BST_H
#define BST_H

#include <iostream>

using std::cout;
using std::endl;
using std::ostream;

template <class T>
class BST {

public:
	// constructor and rule of three
	BST() : mpRoot(nullptr) {};
	BST(const BST<T>& copy) { copyTree(copy.mpRoot, this->mpRoot); }
	~BST() { deleteTree(mpRoot); }

	BST<T>& operator=(const BST<T>& copy) {
		deleteTree(mpRoot);
		mpRoot = nullptr;
		copyTree(copy.mpRoot, this->mpRoot);
		return *this;
	}

	// public member functions
	void insert(const T& toInsert) { mpRoot = insert(toInsert, mpRoot); }
	bool search(const T& toFind) const { return search(toFind, mpRoot); }
	void deleteNode(const T& toDelete) { mpRoot = deleteNode(toDelete, mpRoot); }
	void printInOrder() const { printInOrder(cout, mpRoot); }

	// define operator<< here to avoid gotcha with templates and huge linker errors
	friend ostream& operator<<(ostream& lhs, const BST<T>& rhs) {
		rhs.printInOrder(lhs, rhs.mpRoot);
		return lhs;
	}

private:
	
	// nested node class for BST and only BST to use 
	class Node {

	public:
		Node() : mpLeft(nullptr), mpRight(nullptr), mData(T()) {}
		Node(const T& data) : mpLeft(nullptr), mpRight(nullptr), mData(data) {}
		Node(const Node& copy) : mpLeft(nullptr), mpRight(nullptr), mData(copy.mData) {}
		~Node() {}

		Node& operator=(const Node& copy) {
			if (&copy != this) {
				this->mData = copy.mData;
				this->mpLeft = nullptr;
				this->mpRight = nullptr;
			}

			return *this;
		}

		// these can be public because this class is public to BST but private to everything else
		Node* mpLeft, * mpRight;
		T mData;
	};

	// private member functions
	Node* insert(const T& toInsert, Node* subtree);
	bool search(const T& toFind, Node* subtree) const;
	Node* deleteNode(const T& toDelete, Node* subtree);

	// other helpers
	void deleteTree(Node* subtree);
	void copyTree(const Node* toCopy, Node*& subtree);
	void printInOrder(ostream& out, const Node* subtree) const;
	Node* getSuccessor(const Node* current) const;

	// private data members
	Node* mpRoot;
};

// --------------- PRIVATE BST FUNCTIONS ---------------

template <class T>
BST<T>::Node* BST<T>::insert(const T& toInsert, Node* subtree) {
	// subtree null: return a new node
	if (subtree == nullptr) return new Node(toInsert);

	// duplicate: return pointer to current node
	if (toInsert == subtree->mData) return subtree;

	// toInsert less than current data, recurse left
	if (toInsert < subtree->mData) {
		subtree->mpLeft = insert(toInsert, subtree->mpLeft);
		return subtree;
	}

	// toInsert greater than current data, recurse right
	else {
		subtree->mpRight = insert(toInsert, subtree->mpRight);
		return subtree;
	}
}

template <class T>
bool BST<T>::search(const T& toFind, Node* subtree) const {
	// subtree null: return false for not found
	if (subtree == nullptr) return false;
	
	// found: return true
	if (toFind == subtree->mData) return true;

	// recurse left
	if (toFind < subtree->mData) return search(toFind, subtree->mpLeft);

	// recurse right
	else return search(toFind, subtree->mpRight);
}

template <class T>
BST<T>::Node* BST<T>::deleteNode(const T& toDelete, Node* subtree) {
	// subtree null: node to delete not found, return
	if (subtree == nullptr) return nullptr;

	// recurse left
	if (toDelete < subtree->mData) subtree->mpLeft = deleteNode(toDelete, subtree->mpLeft);

	// recurse right
	else if (toDelete > subtree->mData) subtree->mpRight = deleteNode(toDelete, subtree->mpRight);

	// delete node
	else {
		// node with 0 or 1 children
		if (subtree->mpLeft == nullptr) {
			Node* tmp = subtree->mpRight;
			delete subtree;
			return tmp;
		}
		if (subtree->mpRight == nullptr) {
			Node* tmp = subtree->mpLeft;
			delete subtree;
			return tmp;
		}

		// node with 2 children - replace with in order successor
		Node* successor = getSuccessor(subtree);
		subtree->mData = successor->mData;
		subtree->mpRight = deleteNode(successor->mData, subtree->mpRight);  // recursively delete the one we just replaced subtree with
	}
	return subtree;
}

// other helpers
template <class T>
void BST<T>::deleteTree(Node* subtree) {
	// base case: subtree null; return
	if (subtree == nullptr) return;
	
	// delete left
	deleteTree(subtree->mpLeft);

	// delete right
	deleteTree(subtree->mpRight);

	// delete this
	delete subtree;
}

template <class T>
void BST<T>::copyTree(const Node* toCopy, Node*& subtree) {
	// preorder traversal here

	// base case: no node to copy, just set null and return
	if (toCopy == nullptr) {
		subtree = nullptr;
		return;
	}

	// make root node of subtree
	subtree = new Node(toCopy->mData);

	// make left subtree
	copyTree(toCopy->mpLeft, subtree->mpLeft);

	// make right subtree
	copyTree(toCopy->mpRight, subtree->mpRight);
}

template <class T>
void BST<T>::printInOrder(ostream& out, const Node* subtree) const {
	// base case: subtree null; return
	if (subtree == nullptr) return;
	
	// print left
	printInOrder(out, subtree->mpLeft);

	// print this
	out << subtree->mData << " ";

	// print right
	printInOrder(out, subtree->mpRight);
}

template <class T>
BST<T>::Node* BST<T>::getSuccessor(const Node* current) const {
	// get immediate right node
	Node* curr = current->mpRight;

	// get furthest left node as possible from there
	while (curr != nullptr && curr->mpLeft != nullptr)
		curr = curr->mpLeft;

	return curr;
}

// --------------- OTHER BST FUNCTIONS ---------------

// declaration for tester
void testBSTDeleteNode();

#endif