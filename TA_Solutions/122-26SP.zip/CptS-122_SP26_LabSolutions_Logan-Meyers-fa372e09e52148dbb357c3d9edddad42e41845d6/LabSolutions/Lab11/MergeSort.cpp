#include "MergeSort.hpp"

void testMergeSort() {
	cout << "----- TESTING MERGE SORT -----" << endl;

	vector<int> myVec = { 97, 9, 41, 32, 65, 63, 0, 19, 56, 26 };

	printVec(myVec, "Unsorted");

	mergeSort(myVec);

	printVec(myVec, "Sorted  ");

	cout << endl;
}