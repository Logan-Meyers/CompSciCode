#pragma once

#ifndef HANOI_H
#define HANOI_H

#include "stack.h"
#include <stdlib.h>
#include <math.h>

/* ------------------------------ Special Hanoi Stuctures / Data ------------------------------ */

typedef struct hanoiState {
	StackNode* aPeg;
	StackNode* bPeg;
	StackNode* cPeg;
} HanoiState;

/* ------------------------------ UI/UX ------------------------------ */

// get the peg address stack given a peg number
StackNode* getPeg(HanoiState* state, int pegNum);

// get the peg address stack given a peg number
StackNode** getPegAddr(HanoiState* state, int pegNum);

// get an int from the user with some error handling
int getInt(char *prompt, int retryOnFail, int minInc, int maxInc);

// get the height of a peg (how many disks are on a peg)
int getPegHeight(StackNode* peg);

// print the state of the game
void printHanoi(const HanoiState* state, int disks);

// display menu options
void displayMenu();

// main user input loop / REPL
void hanoiGame();

/* ------------------------------ Hanoi Functions ------------------------------ */

// create the starting state
void startingState(HanoiState* state, int disks);

// check if a move it valid
// 1 = valid, 0 = invalid
int isValidMove(const HanoiState* state, int pegFrom, int pegTo);

// do a move
// PRECONDITION: for proper gameplay, isValidMove must be 1 first
void doMove(HanoiState* state, int pegFrom, int pegTo);

// check if the game is in a won state
int isWon(const HanoiState* state);

#endif