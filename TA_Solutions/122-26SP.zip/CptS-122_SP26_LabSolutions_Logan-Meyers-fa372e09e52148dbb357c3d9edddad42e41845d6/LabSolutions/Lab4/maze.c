/*
- Programmer: Logan Meyers
- Class: CptS 122 Lab #11
- Assignment: Lab 4 Tasks 1-4
- Date: 02/12/2026
- Decription: Stacks! And some applications

- File: maze.c
- Description: function definitions for task 4's maze solver.
*/

#include "maze.h"

#pragma region Random Funcs

void seedRand() {
    srand((unsigned int)time(NULL));
}
int getRandBool() {
    return !(rand() % 3);
}
int getRandRangeInc(int max_inc) {
    return rand() % (max_inc+1);
}
int getRandRangeExcl(int max_excl) {
    return rand() % max_excl;
}

#pragma endregion

#pragma region Stack Operations

int mazeIsEmpty(MazeNode* pTop) {
    return !pTop;
}

int mazePush(MazeNode** pTop, Point newPoint) {
    int alloc_success = 0;

    MazeNode *pMem = (MazeNode *)malloc(sizeof(MazeNode));
    if (pMem) {
        pMem->currentPoint = newPoint;
        pMem->pNext = *pTop;
        *pTop = pMem;
        alloc_success = 1;
    }

    return alloc_success;
}

Point mazePop(MazeNode** pTop) {
    // if list is empty, return 0
    if (mazeIsEmpty(*pTop)) return nullPoint();

    // else get value and pop top MazeNode
    Point top_val = (*pTop)->currentPoint;
    MazeNode *next = (*pTop)->pNext;
    free(*pTop);
    *pTop = next;

    return top_val;
}

Point mazePeek(MazeNode* pTop) {
    return pTop != NULL ? pTop->currentPoint : nullPoint();
}

#pragma endregion

#pragma region Point and Coord Operations

Point nullPoint() {
    Point newPoint = {.coord = {.x = -1, .y = -1}, .forks = {0}};
    return newPoint;
}

int pointAtCoord(MazeNode *stack, Coord tgt) {
    while (stack != NULL) {
        // printf("Checking (%d, %d) against (%d, %d)\n", stack->currentPoint.coord.x, stack->currentPoint.coord.y, tgt.x, tgt.y);
        if (stack->currentPoint.coord.x == tgt.x && stack->currentPoint.coord.y == tgt.y) {
            return 1;
        }
        stack = stack->pNext;
    }

    return 0;
}
int coordsMatch(Coord c1, Coord c2) {
    return (c1.x == c2.x) && (c1.y == c2.y);
}

#pragma endregion

#pragma region Maze Operations

void initMaze(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH]) {
    for (int i=0; i < MAZE_HEIGHT; i++) {
        for (int j=0; j < MAZE_WIDTH; j++) {
            maze_arr[i][j] = 0;
        }
    }
}

void genMaze(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH]) {
    for (int i=0; i < MAZE_HEIGHT; i++) {
        for (int j=0; j < MAZE_WIDTH; j++) {
            maze_arr[i][j] = getRandBool();
        }
    }
}

Point randValidStart(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH]) {
    int iters = 0;
    Point start = nullPoint();

    while (iters < 100) {
        int x = getRandRangeExcl(MAZE_WIDTH);
        if (maze_arr[0][x] == 0) {
            start.coord.x = x;
            start.coord.y = 0;
            break;
        }
        iters++;
    }

    return start;
}
Point randValidEnd(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH]) {
    int iters = 0;
    Point end = nullPoint();

    while (iters < 100) {
        int x = getRandRangeExcl(MAZE_WIDTH);
        if (maze_arr[MAZE_HEIGHT-1][x] == 0) {
            end.coord.x = x;
            end.coord.y = MAZE_HEIGHT-1;
            break;
        }
        iters++;
    }

    return end;
}

void printMaze(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH], Point start, Point end, MazeNode* stack) {
    system("cls");

    // Top border
    printf("+");
    for (int j = 0; j < MAZE_WIDTH; j++) printf("--");
    printf("-+\n");

    for (int i = 0; i < MAZE_HEIGHT; i++) {
        printf("|");
        for (int j = 0; j < MAZE_WIDTH; j++) {
            Coord cur = { j, i };

            // Walk the linked list directly
            int onPath = 0;
            MazeNode* node = stack;
            while (node != NULL) {
                if (coordsMatch(node->currentPoint.coord, cur)) {
                    onPath = 1;
                    break;
                }
                node = node->pNext;
            }

            if (coordsMatch(cur, start.coord)) {
                printf(" S");
            }
            else if (coordsMatch(cur, end.coord)) {
                printf(" E");
            }
            else if (onPath) {
                printf(" .");
            }
            else if (maze_arr[i][j] == 1) {
                printf(" #");
            }
            else {
                printf("  ");
            }
        }
        printf(" |\n");
    }

    // Bottom border
    printf("+");
    for (int j = 0; j < MAZE_WIDTH; j++) printf("--");
    printf("-+\n");
}

// Restrictions: in-bounds, not a wall (0), not visited, not on stack.
static int calcForks(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH], int visited[MAZE_HEIGHT][MAZE_WIDTH],
    MazeNode* stack, Coord cur, Coord forks_out[4]) {
    int dx[] = { 0,  0, -1, 1 };
    int dy[] = { -1, 1,  0, 0 };
    int count = 0;

    for (int d = 0; d < 4; d++) {
        int nx = cur.x + dx[d];
        int ny = cur.y + dy[d];

        if (nx < 0 || nx >= MAZE_WIDTH || ny < 0 || ny >= MAZE_HEIGHT) continue;
        if (maze_arr[ny][nx] == 1) continue;   // wall
        if (visited[ny][nx]) continue;          // already visited

        forks_out[count++] = (Coord){ nx, ny };
    }

    // Fill remaining slots with sentinel
    for (int i = count; i < 4; i++)
        forks_out[i] = (Coord){ -1, -1 };

    return count;
}

static int countForks(Point* p) {
    int count = 0;
    for (int i = 0; i < 4; i++)
        if (p->forks[i].x != -1) count++;
    return count;
}

// This does not the find the most optimized route, but it will most likely find a route nonetheless!
int mazeSolveLoop(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH], Point start, Point end, MazeNode** stack) {
    // visited array — 0 = unvisited, 1 = visited. Walls aren't tracked here
    // since we check maze_arr directly in calcForks.
    int visited[MAZE_HEIGHT][MAZE_WIDTH] = { 0 };

    // push start with forks pre-calculated
    if (mazeIsEmpty(*stack)) {
        visited[start.coord.y][start.coord.x] = 1;
        calcForks(maze_arr, visited, *stack, start.coord, start.forks);
        mazePush(stack, start);
    }

    // solve loop
    while (!mazeIsEmpty(*stack)) {
        // get current point (by reference via pTop so we can mutate forks)
        Point* cur = &(*stack)->currentPoint;

        // check if we're at the end
        if (coordsMatch(cur->coord, end.coord))
            return 1;

        // check forks
        int fc = countForks(cur);
        if (fc > 0) {
            // pick a random valid fork slot
            int choice = getRandRangeExcl(fc);
            int seen = 0;
            Coord next_coord = { -1, -1 };
            for (int i = 0; i < 4; i++) {
                if (cur->forks[i].x == -1) continue;
                if (seen == choice) {
                    next_coord = cur->forks[i];
                    // remove this fork from the current point so we don't revisit it
                    cur->forks[i] = (Coord){ -1, -1 };
                    break;
                }
                seen++;
            }

            // build next point with its own forks
            Point next = nullPoint();
            next.coord = next_coord;

            visited[next_coord.y][next_coord.x] = 1;

            calcForks(maze_arr, visited, *stack, next_coord, next.forks);
            mazePush(stack, next);

        }
        else {
            // no forks — and backtrack
            mazePop(stack);
        }

        // print current state
        //printMaze(maze_arr, start, end, *stack);
    }

    return 0; // no solution
}

void mazeMain() {
    seedRand();

    int maze[MAZE_HEIGHT][MAZE_WIDTH];

    // 0's are CLEAR
    // 1's are WALLS

    initMaze(maze);
    genMaze(maze);

    Point start = randValidStart(maze);
    Point end = randValidEnd(maze);

    printf("Start: %d, %d\n", start.coord.x, start.coord.y);
    printf("End: %d, %d\n", end.coord.x, end.coord.y);

    MazeNode* pTop = NULL;
    printMaze(maze, start, end, pTop);

    int solution = mazeSolveLoop(maze, start, end, &pTop);

    if (solution == 1) {
        printMaze(maze, start, end, pTop);
        printf("Success!! There was is a correct path. You can see it above.\n\n");
    } else
        printf("No solution :(");
}

#pragma endregion