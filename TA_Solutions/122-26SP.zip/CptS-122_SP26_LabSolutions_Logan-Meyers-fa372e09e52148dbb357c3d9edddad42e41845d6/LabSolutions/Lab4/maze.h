/*
- Programmer: Logan Meyers
- Class: CptS 122 Lab #11
- Assignment: Lab 4 Tasks 1-4
- Date: 02/12/2026
- Decription: Stacks! And some applications

- File: maze.h
- Description: function declarations for task 4's maze solver.
*/

// guard code
#ifndef MAZE_H
#define MAZE_H

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h> // REQUIRED for malloc
#include <string.h>
#include <time.h>  // ??
#include <Windows.h>  // for clearing

#define MAZE_WIDTH 20
#define MAZE_HEIGHT 20

// a stack is a restricted list, so the underlying data type isn't any different
typedef struct coord {
	int x;
	int y;
} Coord;

// a point in the maze, with info about where to go next
typedef struct point {
	Coord coord;
	Coord forks[4];
} Point;

// node for maze node stack
typedef struct mazeNode {
	Point currentPoint;
	struct mazeNode* pNext;
} MazeNode;

#pragma region Random Funcs

// helper to seed random
void seedRand();

// biased random function for generating walls/air for maze
int getRandBool();

// helper to generate a random number in a given range, inclusive (unused)
int getRandRangeInc(int max_inc);

// helper to generate a random number in a given range, exclusive
int getRandRangeExcl(int max_excl);

#pragma endregion

#pragma region Stack Operations

// check if empty
int mazeIsEmpty(MazeNode* pTop);

// push onto stack
int mazePush(MazeNode** pTop, Point newPoint);

// pop off stack
Point mazePop(MazeNode** pTop);

// get top of stack
Point mazePeek(MazeNode* pTop);

#pragma endregion

#pragma region Point and Coord Operations

// like default point constructor
Point nullPoint();

// Check the stack of maze nodes (pretending it's a normal linked list) if a coord is in that stack
int pointAtCoord(MazeNode *stack, Coord tgt);

// check if two coords match; i.e. c1.x == c2.x && c1.y == c2.y
int coordsMatch(Coord c1, Coord c2);

#pragma endregion

#pragma region Maze Operations

// fill maze array with 0's (air)
void initMaze(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH]);

// fill maze with random wall placement
void genMaze(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH]);

// get a valid starting spot
Point randValidStart(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH]);

// get a valid ending spot
Point randValidEnd(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH]);

// print the maze! includes walls and path taken
void printMaze(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH], Point start, Point end, MazeNode *stack);

// helper to calculate where a point can go next, given reasonable constraints
int calcForks(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH], int visited[MAZE_HEIGHT][MAZE_WIDTH],
	MazeNode* stack, Coord cur, Coord forks_out[4]);

// helper to count how many forks a point has/can go
int countForks(Point* p);

// main loop for solving maze
int mazeSolveLoop(int maze_arr[MAZE_HEIGHT][MAZE_WIDTH], Point start, Point end, MazeNode **stack);

// called from program main
void mazeMain();

#pragma endregion

#endif
