#include "hanoi.h"

/* ------------------------------ UI/UX ------------------------------ */

StackNode* getPeg(HanoiState* state, int pegNum) {
	if (pegNum == 1) return state->aPeg;
	if (pegNum == 2) return state->bPeg;
	if (pegNum == 3) return state->cPeg;
	return NULL;
}
StackNode** getPegAddr(HanoiState* state, int pegNum) {
	if (pegNum == 1) return &(state->aPeg);
	if (pegNum == 2) return &(state->bPeg);
	if (pegNum == 3) return &(state->cPeg);
	return NULL;
}

int getInt(char* prompt, int retryOnFail, int minInc, int maxInc) {
	int result = -1;

	do {
		printf("%s", prompt);

		char input[32] = { '\0' };

		int scanRes = scanf("%s", input);

		// try to convert if successfully read something
		if (scanRes != EOF && scanRes >= 1) {
			int converted = atoi(input);

			// make sure we got an actual number, and is in the range we want
			if (converted != 0 && converted >= minInc && converted <= maxInc)
				result = converted;
		}

	} while (retryOnFail && result == -1);  // retry if needed & wanted

	return result;
}

int getPegHeight(StackNode* peg) {
	int count = 0;

	StackNode* top = peg;
	while (top != NULL) {
		count++;
		top = top->next;
	}

	return count;
}
void printHanoi(const HanoiState* state, int disks) {
	// number of disks in each peg
	int aHeight = getPegHeight(state->aPeg);
	int bHeight = getPegHeight(state->bPeg);
	int cHeight = getPegHeight(state->cPeg);

	// get max disks on board
	int maxHeight = max(aHeight, max(bHeight, cHeight)) + 1;
	int curHeight = maxHeight;

	// get open spaces until you can start printing disks in the particular peg
	int heightUntilA = maxHeight - aHeight;
	int heightUntilB = maxHeight - bHeight;
	int heightUntilC = maxHeight - cHeight;

	// Node pointers for each peg
	StackNode* aPeg = state->aPeg;
	StackNode* bPeg = state->bPeg;
	StackNode* cPeg = state->cPeg;

	while (curHeight > 0) {
		// print appropriate thing based on each peg
		if (heightUntilA == 0)
			printf("[ %d ] ", (int)aPeg->data);
		else
			printf("  |   ");

		if (heightUntilB == 0)
			printf("[ %d ] ", (int)bPeg->data);
		else
			printf("  |   ");

		if (heightUntilC == 0)
			printf("[ %d ] ", (int)cPeg->data);
		else
			printf("  |   ");

		putchar('\n');

		// process height decrease
		if (heightUntilA > 0) heightUntilA--;
		else aPeg = aPeg->next;

		if (heightUntilB > 0) heightUntilB--;
		else bPeg = bPeg->next;

		if (heightUntilC > 0) heightUntilC--;
		else cPeg = cPeg->next;

		curHeight--;
	}

	printf("--+-- --+-- --+--\n");
	printf("  1     2     3\n");
}
void displayMenu();
void hanoiGame() {
	// get number of disks to play with
	int disks = getInt("How many disks would you like to play with? Enter a whole number in the range [1-9]\n> ", 1, 1, 9);

	// state of the game
	HanoiState state;
	startingState(&state, disks);

	putchar('\n');

	// main loop
	while (!isWon(&state)) {
		printHanoi(&state, disks);

		int pegFrom = getInt("Which peg would you like to move from?\n> ", 1, 1, 3);
		int pegTo = getInt("Which peg would you like to move to?\n> ", 1, 1, 3);

		if (isValidMove(&state, pegFrom, pegTo)) {
			doMove(&state, pegFrom, pegTo);
		}
		else {
			printf("Invalid move! Try again.\n\n");
		}
	}
	
	printf("\nYou won!!!\n");
	printHanoi(&state, disks);
}

/* ------------------------------ Hanoi Functions ------------------------------ */

void startingState(HanoiState* state, int disks) {
	// null's required to avoid pointer being not null and having accessing issus
	state->aPeg = NULL;
	state->bPeg = NULL;
	state->cPeg = NULL;

	// init a peg with all disks
	for (; disks > 0; disks--) push(&((*state).aPeg), disks);
}
int isValidMove(const HanoiState* state, int pegFrom, int pegTo) {
	// values at top of pegs chosen
	int fromVal = 0, toVal = 0;

	// get value at top of peg to go from
	if (pegFrom == 1) fromVal = peek(state->aPeg);
	if (pegFrom == 2) fromVal = peek(state->bPeg);
	if (pegFrom == 3) fromVal = peek(state->cPeg);

	// get value at top of peg to go to
	if (pegTo == 1) toVal = peek(state->aPeg);
	if (pegTo == 2) toVal = peek(state->bPeg);
	if (pegTo == 3) toVal = peek(state->cPeg);

	// conditions
	if (pegFrom == pegTo) return 0;
	if (toVal == 0) return 1;
	if (toVal > fromVal) return 1;

	return 0;
}
// precondition: isValidMove() is called before and returns 1 (true)
void doMove(HanoiState* state, int pegFrom, int pegTo) {
	StackNode** pegToAddr = getPegAddr(state, pegTo);
	StackNode** pegFromAddr = getPegAddr(state, pegFrom);
	double pegFromVal = peek(getPeg(state, pegFrom));

	push(pegToAddr, pegFromVal);
	pop(pegFromAddr);
}
int isWon(const HanoiState* state) {
	// conditions:
	if (
		state->aPeg == NULL &&  // all moved from first peg
			(
			(peek(state->bPeg) == 1 && state->cPeg == NULL) ||  // all in second peg, or:
			(peek(state->cPeg) == 1 && state->bPeg == NULL)     // all in third peg
			)
		) return 1;
	
	return 0;
}