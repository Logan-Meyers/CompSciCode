/*
- Programmer: Logan Meyers
- Class: CptS 122 Lab #11
- Assignment: Lab 4 Tasks 1-4
- Date: 02/12/2026
- Decription: Stacks! And some applications
*/

#include "stack.h"
#include "testStack.h"
#include "hanoi.h"
#include "maze.h"

int main()
{
	// task 1
	testAll();
	demoStack();

	// task 2
	printf("\n----- Tower of Hanoi Game -----\n\n");
	printf("Would you like to play the game? (y/n)\n> ");

	char answer[10] = { '\0' };
	scanf("%s", answer);

	if (answer[0] == 'y' || answer[0] == 'Y')
		hanoiGame();

	// task 3
	printf("\n----- Maze Solver -----\n\n");
	printf("Would you like to show the maze solver? (y/n)\n> ");

	answer[0] = '\0';
	scanf("%s", answer);

	if (answer[0] == 'y' || answer[0] == 'Y')
		mazeMain();
}