/*
- Programmer: Logan Meyers
- Class: CptS 122 Lab #11
- Assignment: Lab 4 Tasks 1-4
- Date: 02/12/2026
- Decription: Stacks! And some applications

- File: stack.c
- Description: function definitions for task 1's stack.
*/

#include "stack.h"

/* ------------------------------ Stack Struct/Functions ------------------------------ */

int isEmpty(StackNode* stack) {
	return stack == NULL;
}

int	push(StackNode** stack, double data) {
	StackNode* pMem = (StackNode *)malloc(sizeof(StackNode));

	if (pMem == NULL) return 0;

	//pMem->next = *stack ? *stack : NULL;
	pMem->next = NULL;
	if (*stack) pMem->next = *stack;
	pMem->data = data;

	*stack = pMem;

	return 1;
}

void pop(StackNode** stack) {
	if (isEmpty(*stack)) return;
	
	StackNode* tmp = *stack;
	*stack = tmp->next;
	
	free(tmp);
}
double peek(StackNode* stack) {
	return stack ? stack->data : 0;
}

void destroy(StackNode** stack) {
	StackNode* top = *stack;

	while (top) {
		StackNode* tmp = top;
		top = top->next;
		free(tmp);
	}

	*stack = NULL;
}

/* ------------------------------ Stack Demo ------------------------------ */

void printStack(StackNode* stack) {
	printf("Stack:");

	while (stack) {
		printf(" --> %f", stack->data);
		stack = stack->next;
	}

	printf(".\n");
}

void demoStack() {
	printf("\n----- Demoing Stack Functionality -----\n\n");
	printf("Created stack:\n");
	StackNode* stack = NULL;
	push(&stack, 1);
	push(&stack, 2);
	push(&stack, 3);
	push(&stack, 4);
	push(&stack, 5);
	printStack(stack);

	printf("After popping top two off:\n");
	printf("- Popping %f\n", peek(stack));
	pop(&stack);
	printf("- Popping %f\n", peek(stack));
	pop(&stack);
	printStack(stack);

	destroy(&stack);
}