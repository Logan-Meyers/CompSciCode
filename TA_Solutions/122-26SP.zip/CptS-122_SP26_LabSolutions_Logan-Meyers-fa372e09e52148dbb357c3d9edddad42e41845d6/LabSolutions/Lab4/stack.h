/*
- Programmer: Logan Meyers
- Class: CptS 122 Lab #11
- Assignment: Lab 4 Tasks 1-4
- Date: 02/12/2026
- Decription: Stacks!

- File: stack.h
- Description: function and struct declerations for task 1's stack
*/

#pragma once

#ifndef STACK_H
#define STACK_H

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>

/* ------------------------------ Stack Struct/Functions ------------------------------ */

typedef struct stackNode {
	double data;
	struct stackNode* next;
} StackNode;

// checks if a stack is empty;
// 1 = empty, 0 = full
int isEmpty(StackNode* stack);

// push an item onto the stack and update pointer to top of stack
int	push(StackNode** stack, double data);

// pop an item off of the stack ad update pointer to top of stack
void pop(StackNode** stack);

// return the data at the top of the stack
double peek(StackNode* stack);

// additional destroy function, removes all nodes
void destroy(StackNode** stack);

/* ------------------------------ Stack Demo ------------------------------ */
// niceley print stack, for debugging! (pretends it's a singly-linked LIST)
void printStack(StackNode* stack);

// Function to demo stack functionality
void demoStack();

#endif