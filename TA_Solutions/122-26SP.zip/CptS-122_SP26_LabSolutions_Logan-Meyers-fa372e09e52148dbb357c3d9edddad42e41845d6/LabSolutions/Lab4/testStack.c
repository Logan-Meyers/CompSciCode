/*
- Programmer: Logan Meyers
- Class: CptS 122 Lab #11
- Assignment: Lab 4 Tasks 1-4
- Date: 02/12/2026
- Decription: Stacks! And some applications

- File: testStack.c
- Description: function definitions for task 2's stack testing functions.
*/

#include "testStack.h"

void printResult(char* testName, int res) {
	printf("-- Test %s was a ", testName);

	if (res)
		printf("SUCCESS");
	else
		printf("FAIL!");

	putchar('\n');
}
void testAll() {
	printf("----- Testing Stack Functions! -----\n\n");
	printResult("Push", testPush());
	printResult("Is Empty", testIsEmpty());
	printResult("Peek", testPeek());
	printResult("Pop", testPop());
	printResult("Destroy", testDestroy());
}
int testPush() {
	StackNode* stack = NULL;

	push(&stack, 1);

	if (
		stack == NULL ||
		stack->data != 1
		) return 0;

	return 1;
}
int testIsEmpty() {
	StackNode* stack = NULL;

	push(&stack, 1);

	if (
		stack == NULL ||
		stack->data != 1 ||
		isEmpty(stack) != 0
		) return 0;

	return 1;
}
int testPeek() {
	StackNode* stack = NULL;

	push(&stack, 1);

	if (
		stack == NULL ||
		stack->data != 1 ||
		peek(stack) != 1
		) return 0;

	return 1;
}
int testPop() {
	StackNode* stack = NULL;

	push(&stack, 1);

	if (
		stack == NULL ||
		stack->data != 1
		) return 0;

	pop(&stack);

	if (stack != NULL)
		return 0;

	return 1;
}
int testDestroy() {
	StackNode* stack = NULL;

	push(&stack, 1);
	push(&stack, 2);
	push(&stack, 3);
	push(&stack, 4);

	if (
		stack == NULL ||
		peek(stack) != 4
		) return 0;

	destroy(&stack);

	if (stack != NULL)
		return 0;

	return 1;
}