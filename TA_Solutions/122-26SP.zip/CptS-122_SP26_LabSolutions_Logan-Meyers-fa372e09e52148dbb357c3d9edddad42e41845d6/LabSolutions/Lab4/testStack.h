/*
- Programmer: Logan Meyers
- Class: CptS 122 Lab #11
- Assignment: Lab 4 Tasks 1-4
- Date: 02/12/2026
- Decription: Stacks! And some applications

- File: testStack.h
- Description: function declerations for task 2's stack testing functions.
*/

#pragma once

#ifndef TEST_STACK_H
#define TEST_STACK_H

#include "stack.h"

void printResult(char *testName, int res);
void testAll();
int testPush();
int testIsEmpty();
int testPeek();
int testPop();
int testDestroy();

#endif