#pragma once

#ifndef CREDIT_REPORT_H
#define CREDIT_REPORT_H

#include <iostream>

// custom class with optional parameters via pointers
typedef struct reportUpdateData {
	int* creditScore;
	double* realEstateDebt;
	double* creditCardDebt;
	int* numRealEstateAccounts;
	int* numCreditCards;
	int* numRetailCards;
	int* oldestAccountAge;
	double* averageAccountAge;
	int* numHardInquiries;
} ReportUpdateData;

class CreditReport {
	
public:
	CreditReport();
	CreditReport(double reDebt, double ccDebt, int numReAcc, int numCC, int numReCards,
			int oldestAcc, double avgAcc, int numInquiries);
	CreditReport(const CreditReport& copy);
	~CreditReport();

	// core functionality - updating & printing
	void updateReport(ReportUpdateData toUpdate);
	void print();

	// getters
	int getCreditscore() const;
	double getRealEstateDebt() const;
	double getCreditCardDebt() const;
	int getNumRealEstateAccounts() const;
	int getNumCreditCards() const;
	int getNumRetailCards() const;
	int getOldestAccountAge() const;
	double getAverageAccountAge() const;
	int getNumHardInquiries() const;
	
	// setters
	void setCreditscore(int newCreditscore);
	void setRealEstateDebt(double newRealEstateDebt);
	void setCreditCardDebt(double newCreditCardDebt);
	void setNumRealEstateAccounts(int newNumRealEstateAccounts);
	void setNumCreditCards(int newNumCreditCards);
	void setNumRetailCards(int newNumRetailCards);
	void setOldestAccountAge(int newOldestAccountAge);
	void setAverageAccountAge(double newAverageAccountAge);
	void setNumHardInquiries(int newNumHardInquiries);

	friend std::ostream& operator<<(std::ostream& lhs, const CreditReport& rhs);

private:
	int creditScore;
	double realEstateDebt;
	double creditCardDebt;
	int numRealEstateAccounts;
	int numCreditCards;
	int numRetailCards;
	int oldestAccountAge;  // years
	double averageAccountAge;  // years
	int numHardInquiries;

	// custom hidden calculate function
	void calculateScore();
};

#endif