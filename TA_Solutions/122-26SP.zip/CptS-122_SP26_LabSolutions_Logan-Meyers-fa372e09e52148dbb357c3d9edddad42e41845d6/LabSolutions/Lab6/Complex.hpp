#pragma once

#ifndef COMPLEX_H
#define COMPLEX_H

#include <iostream>

class Complex {

public:
	Complex(double realPart = 0, double imaginaryPart = 0);  // default construtor
	Complex(const Complex& rhs);  // copy constructor
	Complex& operator= (const Complex& rhs);  // copy assignment
	~Complex();  // destructor

	// getters
	double getRealPart() const;
	double getImaginaryPart() const;

	// setters
	void setRealPart(double newReal);
	void setImaginaryPart(double newImaginary);

	// custom member functions
	Complex add(const Complex& rhs);  // add to current and return result
	void read();
	void print() const;

	// overloaded operations
	friend std::ostream& operator<< (std::ostream& lhs, const Complex& rhs);  // string insertion
	friend std::istream& operator>> (std::istream& lhs, Complex& rhs);  // string extraction

private:
	double realPart;
	double imaginaryPart;
};

// non-member add
Complex add(const Complex& lhs, const Complex& rhs);

// non-member + operator overload
Complex operator+ (const Complex& lhs, const Complex& rhs);

// non-member - operator overload
Complex operator- (const Complex& lhs, const Complex& rhs);

#endif