#include "Complex.hpp"
#include "CreditReport.hpp"

int main() {
	Complex c1(3.5, 2), c2(5.5, 7), c3;
	Complex a, b;

	c3 = c1.add(c2); // member add () function
	std::cout << c3 << std::endl;

	c3 = add(c1, c2); // non-member add () function
	std::cout << c3 << std::endl;

	c3 = c1 + c2; // overloaded + operator
	std::cout << c3 << std::endl;

	std::cout << "Enter first complex number here (format # +/- #i): ";
	std::cin >> a;
	std::cout << "Enter second complex number here (format # +/- #i): ";
	std::cin >> b;
	std::cout << "a + b = " << a << " + " << b << " = " << a+b << std::endl;
	std::cout << "a - b = " << a << " - " << b << " = " << a - b << std::endl;

	std::cout << c1 + c2 + c3 << std::endl;

	// instantiate three reports
	CreditReport reportExperian, reportTransUnion, reportEquifax;

	// below, test it out yourself!
	// ...

	return 0;
}
