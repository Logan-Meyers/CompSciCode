#include "Complex.hpp"

/* --------------- Constructors & Rule of Three --------------- */

// default constructor
Complex::Complex(double real, double imaginaryPart) {
	// inconsistent naming intentional here!

	// set member variable to parameter, as you'd expect
	realPart = real;

	// set member variable (explicitly in member scope)
	// and assign to parameter with same name
	this->imaginaryPart = imaginaryPart;
}

// copy constructor
Complex::Complex(const Complex& rhs) {
	this->realPart = rhs.realPart;
	this->imaginaryPart = rhs.imaginaryPart;
}

// copy assignment
Complex& Complex::operator= (const Complex& rhs) {
	// this makes sure that we're not setting it equal
	// to itself
	if (this != &rhs) {
		this->realPart = rhs.realPart;
		this->imaginaryPart = rhs.imaginaryPart;
	}

	return *this;
}

// destructor
Complex::~Complex() {}

/* --------------- Getters & Setters --------------- */

// getters
double Complex::getRealPart() const {
	return this->realPart;
}
double Complex::getImaginaryPart() const {
	return this->imaginaryPart;
}

// setters
void Complex::setRealPart(double newReal) {
	this->realPart = newReal;
}
void Complex::setImaginaryPart(double newImaginary) {
	this->imaginaryPart = newImaginary;
}

/* --------------- Custom Member functions --------------- */

Complex Complex::add(const Complex& rhs) {
	this->realPart += rhs.realPart;
	this->imaginaryPart += rhs.imaginaryPart;

	return *this;
}

void Complex::read() {
	std::cin >> *this;
}
void Complex::print() const {
	std::cout << *this;
}

/* --------------- Operator Overloading --------------- */

std::ostream& operator<< (std::ostream& lhs, const Complex& rhs) {
	lhs << rhs.realPart;
	
	if (rhs.imaginaryPart < 0)
		lhs << " - " << -rhs.imaginaryPart;
	else
		lhs << " + " << rhs.imaginaryPart;

	lhs << "i";

	return lhs;
}

std::istream& operator>> (std::istream& lhs, Complex& rhs) {
	// sign
	char c;
	int sign = 1;

	// read double for real
	lhs >> rhs.realPart;

	// read whitespace to sign
	lhs >> std::ws;

	// set sign & consume
	c = lhs.peek();
	if (c == '+' || c == '-') {
		lhs.get();  // consume single char, the one we just peeked
		if (c == '-') sign = -1;
	}
	lhs >> std::ws;

	// read next double (skips whitespace)
	// if given, else 1 into imaginary part
	if (lhs.peek() != 'i') {
		lhs >> rhs.imaginaryPart;
		rhs.imaginaryPart *= sign;
	}
	else {
		rhs.imaginaryPart = 1 * sign;  // user wrote just 'i' which mean 1 i
	}

	// read i if it exists
	if (lhs.peek() == 'i') lhs >> c;

	return lhs;
}

/* --------------- Non-Member Functions --------------- */
Complex add(const Complex& lhs, const Complex& rhs) {
	return Complex(lhs.getRealPart() + rhs.getRealPart(),
				   lhs.getImaginaryPart() + rhs.getImaginaryPart());
}

Complex operator+ (const Complex& lhs, const Complex& rhs) {
	return Complex(lhs.getRealPart() + rhs.getRealPart(),
				   lhs.getImaginaryPart() + rhs.getImaginaryPart());
}

Complex operator- (const Complex& lhs, const Complex& rhs) {
	return Complex(lhs.getRealPart() - rhs.getRealPart(),
				   lhs.getImaginaryPart() - rhs.getImaginaryPart());
}