# CptS-122_SP26_LabSolutions_Logan-Meyers

My solutions to the lab tasks, and possibly some other things.

_If you need some inspiration on how to solve a task, here's a decent place to look!_

## Table of Contents

- [Table of contents](#table-of-contents)
- [How to Use](#how-to-use)
- [Constraints](#constraints)
- [Layout & Solutions](#layout--solutions)

## How to Use

Each lab's solution with be available as an individual "Release" for this repo ([here is the releases page](https://github.com/Logan-Meyers/CptS-122_SP26_LabSolutions_Logan-Meyers/releases)). You may download the .zip solution and view the solutions in Visual Studio 2026.

Alternatively, you can download the whole repo and get access to all the solutions.

## Constraints

A couple notes:
- This repo is purely for **educational purposes**. You may use this for inspiration and reference only. I.e., no blatant copy + paste into assignments, PAs, etc.
- This repo will be updated at the end of each week (Friday or Saturday most likely), _after_ all the labs for the class have taken place. The reason for the delay is for obvious reasons.
- This repo will disappear at the end of the semester, unless Andy says otherwise.

## Layout & Solutions

Layout of files and projects, plus a date:

```
CptS-122_SP26_LabSolutions_Logan-Meyers/
 └ LabSolutions     | Each lab as a project in this main solution
    ├ Lab 1         | 01/22/2026: HelloWorld, strcat, reverse string, strtok, and string merges
    ├ Lab 2         | 01/29/2026: Singly Linked List
    ├ Lab 3         | 02/05/2026: Doubly Linked List
    ├ Lab 4         | 02/12/2026: Stacks! Tower of Hanoi and a Maze Solver!
    ├ Lab 5         | 02/19/2026: More practice with pointers, lists, and stacks in C
    ├ Lab 6         | 02/26/2026: Intro to C++ with Complex and CreditReport classes
    ├ Lab 7         | 03/05/2026: Linked lists in C++ (shallow and deep copy) and more on classes & member functions
    ├ Lab 8         | 03/12/2026: Queues in C++ and work on PA5
    ├ Lab 9         | 03/26/2026: BST Practice
    ├ Lab 10        | 04/02/2026: Template practice with a Stack! (And some postfix too)
    └ Lab 11        | 04/09/2026: MergeSort (My solution uses a Vector) and BST Delete Node (I use a template BST here)
```

<!-- Special characters: └ ├ -->
