#pragma once

#include "List.h"

template<class NODETYPE>
class Queue : private List<NODETYPE>
{
public:
    void enqueue(const NODETYPE& newData);
    bool dequeue(NODETYPE& removedData);
    bool isEmpty() const;
    void print() const;
};

template<class NODETYPE>
void Queue<NODETYPE>::enqueue(const NODETYPE& newData)
{
    List<NODETYPE>::insertAtBack(newData);
}

template<class NODETYPE>
bool Queue<NODETYPE>::dequeue(NODETYPE& removedData)
{
    return List<NODETYPE>::removeFromFront(removedData);
}

template<class NODETYPE>
bool Queue<NODETYPE>::isEmpty() const
{
    return List<NODETYPE>::isEmpty();
}

template<class NODETYPE>
void Queue<NODETYPE>::print() const
{
    List<NODETYPE>::print();
}
