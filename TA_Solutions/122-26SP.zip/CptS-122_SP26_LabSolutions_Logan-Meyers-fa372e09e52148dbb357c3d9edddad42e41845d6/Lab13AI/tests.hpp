#pragma once

bool runAllTests();
