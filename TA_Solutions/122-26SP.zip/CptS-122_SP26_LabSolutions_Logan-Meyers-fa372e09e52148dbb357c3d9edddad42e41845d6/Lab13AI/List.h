#pragma once

#include <iostream>

template<class NODETYPE>
class List;

template<class NODETYPE>
class ListNode
{
    friend class List<NODETYPE>;

public:
    explicit ListNode(const NODETYPE& newData);
    NODETYPE getData() const;

private:
    NODETYPE data;
    ListNode<NODETYPE>* nextPtr;
};

template<class NODETYPE>
class List
{
public:
    List();
    ~List();

    void insertAtFront(const NODETYPE& newData);
    void insertAtBack(const NODETYPE& newData);
    bool removeFromFront(NODETYPE& removedData);
    bool removeFromBack(NODETYPE& removedData);
    bool isEmpty() const;
    void print() const;

private:
    ListNode<NODETYPE>* firstPtr;
    ListNode<NODETYPE>* lastPtr;

    ListNode<NODETYPE>* getNewNode(const NODETYPE& newData);

    List(const List&) = delete;
    List& operator=(const List&) = delete;
};

template<class NODETYPE>
ListNode<NODETYPE>::ListNode(const NODETYPE& newData)
    : data(newData), nextPtr(nullptr)
{
}

template<class NODETYPE>
NODETYPE ListNode<NODETYPE>::getData() const
{
    return data;
}

template<class NODETYPE>
List<NODETYPE>::List()
    : firstPtr(nullptr), lastPtr(nullptr)
{
}

template<class NODETYPE>
List<NODETYPE>::~List()
{
    while (firstPtr != nullptr)
    {
        ListNode<NODETYPE>* tempPtr = firstPtr;
        firstPtr = firstPtr->nextPtr;
        delete tempPtr;
    }

    lastPtr = nullptr;
}

template<class NODETYPE>
void List<NODETYPE>::insertAtFront(const NODETYPE& newData)
{
    ListNode<NODETYPE>* newPtr = getNewNode(newData);

    if (isEmpty())
    {
        firstPtr = lastPtr = newPtr;
    }
    else
    {
        newPtr->nextPtr = firstPtr;
        firstPtr = newPtr;
    }
}

template<class NODETYPE>
void List<NODETYPE>::insertAtBack(const NODETYPE& newData)
{
    ListNode<NODETYPE>* newPtr = getNewNode(newData);

    if (isEmpty())
    {
        firstPtr = lastPtr = newPtr;
    }
    else
    {
        lastPtr->nextPtr = newPtr;
        lastPtr = newPtr;
    }
}

template<class NODETYPE>
bool List<NODETYPE>::removeFromFront(NODETYPE& removedData)
{
    if (isEmpty())
    {
        return false;
    }

    ListNode<NODETYPE>* tempPtr = firstPtr;
    removedData = firstPtr->data;

    if (firstPtr == lastPtr)
    {
        firstPtr = lastPtr = nullptr;
    }
    else
    {
        firstPtr = firstPtr->nextPtr;
    }

    delete tempPtr;
    return true;
}

template<class NODETYPE>
bool List<NODETYPE>::removeFromBack(NODETYPE& removedData)
{
    if (isEmpty())
    {
        return false;
    }

    ListNode<NODETYPE>* tempPtr = lastPtr;
    removedData = lastPtr->data;

    if (firstPtr == lastPtr)
    {
        firstPtr = lastPtr = nullptr;
    }
    else
    {
        ListNode<NODETYPE>* currentPtr = firstPtr;
        while (currentPtr->nextPtr != lastPtr)
        {
            currentPtr = currentPtr->nextPtr;
        }

        lastPtr = currentPtr;
        lastPtr->nextPtr = nullptr;
    }

    delete tempPtr;
    return true;
}

template<class NODETYPE>
bool List<NODETYPE>::isEmpty() const
{
    return firstPtr == nullptr;
}

template<class NODETYPE>
void List<NODETYPE>::print() const
{
    if (isEmpty())
    {
        std::cout << "The list is empty." << std::endl;
        return;
    }

    ListNode<NODETYPE>* currentPtr = firstPtr;
    while (currentPtr != nullptr)
    {
        std::cout << currentPtr->data;

        if (currentPtr->nextPtr != nullptr)
        {
            std::cout << ' ';
        }

        currentPtr = currentPtr->nextPtr;
    }

    std::cout << std::endl;
}

template<class NODETYPE>
ListNode<NODETYPE>* List<NODETYPE>::getNewNode(const NODETYPE& newData)
{
    return new ListNode<NODETYPE>(newData);
}
