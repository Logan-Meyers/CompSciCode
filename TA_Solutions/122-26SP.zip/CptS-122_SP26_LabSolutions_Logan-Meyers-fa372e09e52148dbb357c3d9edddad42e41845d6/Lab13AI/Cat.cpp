#include "Cat.h"

Cat::Cat()
{
    std::cout << "Cat constructor..." << std::endl;
}

Cat::~Cat()
{
    std::cout << "Cat destructor..." << std::endl;
}

void Cat::Move() const
{
    std::cout << "Cat prowls gracefully!" << std::endl;
}

void Cat::Speak() const
{
    std::cout << "Cat says: Meow!" << std::endl;
}
