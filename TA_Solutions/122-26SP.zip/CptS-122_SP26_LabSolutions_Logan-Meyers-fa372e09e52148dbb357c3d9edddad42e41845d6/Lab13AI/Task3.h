#pragma once

class NonVirtualBase
{
public:
    void testFunction();
};

class NonVirtualDerived : public NonVirtualBase
{
public:
    void testFunction();
};

class Base
{
public:
    virtual ~Base() = default;
    virtual void testFunction();
};

class Derived : public Base
{
public:
    void testFunction() override;
};
