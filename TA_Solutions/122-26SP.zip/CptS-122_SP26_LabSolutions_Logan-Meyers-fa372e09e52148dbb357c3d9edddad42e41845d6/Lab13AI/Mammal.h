#pragma once

#include <iostream>

class Mammal
{
public:
    Mammal();
    virtual ~Mammal();

    virtual void Move() const;
    virtual void Speak() const;

protected:
    int itsAge;
};
