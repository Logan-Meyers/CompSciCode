#pragma once

#include "Mammal.h"

class Horse : public Mammal
{
public:
    Horse();
    ~Horse() override;

    void Move() const override;
    void Speak() const override;
};
