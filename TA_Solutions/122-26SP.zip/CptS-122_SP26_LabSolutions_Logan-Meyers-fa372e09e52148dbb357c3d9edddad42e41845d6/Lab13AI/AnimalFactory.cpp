#include "AnimalFactory.h"

#include "Cat.h"
#include "Dog.h"
#include "GuineaPig.h"
#include "Horse.h"

Mammal* createMammalFromChoice(int choice)
{
    switch (choice)
    {
    case 1:
        return new Dog;
    case 2:
        return new Cat;
    case 3:
        return new Horse;
    case 4:
        return new GuineaPig;
    default:
        return new Mammal;
    }
}
