#include "Task3.h"

#include <iostream>

void NonVirtualBase::testFunction()
{
    std::cout << "Base class" << std::endl;
}

void NonVirtualDerived::testFunction()
{
    std::cout << "Derived class" << std::endl;
}

void Base::testFunction()
{
    std::cout << "Base class" << std::endl;
}

void Derived::testFunction()
{
    std::cout << "Derived class" << std::endl;
}
