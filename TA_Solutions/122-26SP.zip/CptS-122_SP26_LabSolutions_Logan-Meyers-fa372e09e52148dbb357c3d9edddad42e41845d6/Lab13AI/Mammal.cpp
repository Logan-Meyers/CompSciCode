#include "Mammal.h"

Mammal::Mammal()
    : itsAge(1)
{
    std::cout << "Mammal constructor..." << std::endl;
}

Mammal::~Mammal()
{
    std::cout << "Mammal destructor..." << std::endl;
}

void Mammal::Move() const
{
    std::cout << "Mammal moves a step!" << std::endl;
}

void Mammal::Speak() const
{
    std::cout << "What does a mammal speak? Mammilian!" << std::endl;
}
