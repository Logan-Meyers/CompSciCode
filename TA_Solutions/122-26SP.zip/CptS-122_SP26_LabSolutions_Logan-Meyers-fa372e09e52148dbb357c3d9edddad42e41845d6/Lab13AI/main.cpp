#include "AnimalFactory.h"
#include "Dog.h"
#include "List.h"
#include "Queue.h"
#include "Task3.h"

#include <iostream>
#include <limits>
#include <memory>
#include <string>
#include <vector>

namespace
{
void runTask1AndTask2Demo()
{
    std::cout << "Task 1 - List demo" << std::endl;
    List<int> numbers;
    numbers.insertAtFront(20);
    numbers.insertAtFront(10);
    numbers.insertAtBack(30);
    numbers.print();

    int removed = 0;
    numbers.removeFromFront(removed);
    std::cout << "Removed from front: " << removed << std::endl;
    numbers.removeFromBack(removed);
    std::cout << "Removed from back: " << removed << std::endl;
    numbers.print();

    std::cout << std::endl;
    std::cout << "Task 2 - Queue demo" << std::endl;
    Queue<std::string> tasks;
    tasks.enqueue("start");
    tasks.enqueue("study");
    tasks.enqueue("submit");
    tasks.print();

    std::string dequeued;
    while (tasks.dequeue(dequeued))
    {
        std::cout << "Dequeued: " << dequeued << std::endl;
    }
}

void runTask3Demo()
{
    std::cout << std::endl;
    std::cout << "Task 3 - Non-virtual vs virtual dispatch" << std::endl;

    NonVirtualDerived nonVirtualDerived;
    NonVirtualBase* nonVirtualPtr = &nonVirtualDerived;
    std::cout << "Without virtual: ";
    nonVirtualPtr->testFunction();

    std::unique_ptr<Base> virtualPtr = std::make_unique<Derived>();
    std::cout << "With virtual: ";
    virtualPtr->testFunction();
}

void runTask4Demo()
{
    std::cout << std::endl;
    std::cout << "Task 4 - Mammal and Dog" << std::endl;

    std::unique_ptr<Mammal> pDog = std::make_unique<Dog>();
    pDog->Move();
    pDog->Speak();

    std::unique_ptr<Dog> pDog2 = std::make_unique<Dog>();
    pDog2->Move();
    pDog2->Speak();
}

void runTask5Demo()
{
    std::cout << std::endl;
    std::cout << "Task 5 - Choose five animals" << std::endl;

    std::vector<std::unique_ptr<Mammal>> animals;
    animals.reserve(5);

    for (int i = 0; i < 5; ++i)
    {
        int choice = 0;
        std::cout << "(1)dog (2)cat (3)horse (4)guinea pig: ";

        if (!(std::cin >> choice))
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            choice = 0;
        }

        animals.emplace_back(createMammalFromChoice(choice));
    }

    for (const auto& animal : animals)
    {
        animal->Speak();
    }
}
}

int main()
{
    runTask1AndTask2Demo();
    runTask3Demo();
    runTask4Demo();
    runTask5Demo();
    return 0;
}
