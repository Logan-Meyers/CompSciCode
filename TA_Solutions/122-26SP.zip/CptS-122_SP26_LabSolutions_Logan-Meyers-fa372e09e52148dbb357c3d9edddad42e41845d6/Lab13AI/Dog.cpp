#include "Dog.h"

Dog::Dog()
{
    std::cout << "Dog constructor..." << std::endl;
}

Dog::~Dog()
{
    std::cout << "Dog destructor..." << std::endl;
}

void Dog::Move() const
{
    std::cout << "Dog runs on four paws!" << std::endl;
}

void Dog::Speak() const
{
    std::cout << "Dog says: Woof!" << std::endl;
}
