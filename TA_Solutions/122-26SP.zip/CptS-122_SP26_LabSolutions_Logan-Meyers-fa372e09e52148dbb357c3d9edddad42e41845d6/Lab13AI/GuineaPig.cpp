#include "GuineaPig.h"

GuineaPig::GuineaPig()
{
    std::cout << "GuineaPig constructor..." << std::endl;
}

GuineaPig::~GuineaPig()
{
    std::cout << "GuineaPig destructor..." << std::endl;
}

void GuineaPig::Move() const
{
    std::cout << "Guinea pig scurries in short bursts!" << std::endl;
}

void GuineaPig::Speak() const
{
    std::cout << "Guinea pig says: Weep weep!" << std::endl;
}
