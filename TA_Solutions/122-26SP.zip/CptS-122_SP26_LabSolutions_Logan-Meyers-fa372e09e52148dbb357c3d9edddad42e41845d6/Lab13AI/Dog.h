#pragma once

#include "Mammal.h"

class Dog : public Mammal
{
public:
    Dog();
    ~Dog() override;

    void Move() const override;
    void Speak() const override;
};
