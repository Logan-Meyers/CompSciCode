#pragma once

#include "Mammal.h"

class GuineaPig : public Mammal
{
public:
    GuineaPig();
    ~GuineaPig() override;

    void Move() const override;
    void Speak() const override;
};
