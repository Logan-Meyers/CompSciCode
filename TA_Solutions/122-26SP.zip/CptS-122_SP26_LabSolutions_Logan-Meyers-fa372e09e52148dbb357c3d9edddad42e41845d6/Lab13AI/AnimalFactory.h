#pragma once

#include "Mammal.h"

Mammal* createMammalFromChoice(int choice);
