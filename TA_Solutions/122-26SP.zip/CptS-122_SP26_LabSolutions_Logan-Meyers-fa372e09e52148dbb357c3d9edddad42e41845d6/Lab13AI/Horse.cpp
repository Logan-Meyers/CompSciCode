#include "Horse.h"

Horse::Horse()
{
    std::cout << "Horse constructor..." << std::endl;
}

Horse::~Horse()
{
    std::cout << "Horse destructor..." << std::endl;
}

void Horse::Move() const
{
    std::cout << "Horse gallops across the field!" << std::endl;
}

void Horse::Speak() const
{
    std::cout << "Horse says: Neigh!" << std::endl;
}
