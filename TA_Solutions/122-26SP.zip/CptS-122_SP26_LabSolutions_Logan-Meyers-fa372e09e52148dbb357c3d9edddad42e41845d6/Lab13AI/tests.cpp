#include "tests.hpp"

#include "AnimalFactory.h"
#include "Cat.h"
#include "Dog.h"
#include "GuineaPig.h"
#include "Horse.h"
#include "List.h"
#include "Queue.h"
#include "Task3.h"

#include <functional>
#include <iostream>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace
{
std::string captureOutput(const std::function<void()>& action)
{
    std::ostringstream buffer;
    std::streambuf* originalBuffer = std::cout.rdbuf(buffer.rdbuf());

    try
    {
        action();
    }
    catch (...)
    {
        std::cout.rdbuf(originalBuffer);
        throw;
    }

    std::cout.rdbuf(originalBuffer);
    return buffer.str();
}

void expectTrue(bool condition, const std::string& message)
{
    if (!condition)
    {
        throw std::runtime_error(message);
    }
}

void expectContains(const std::string& text, const std::string& expected, const std::string& message)
{
    if (text.find(expected) == std::string::npos)
    {
        throw std::runtime_error(message + " Expected to find: " + expected + " In: " + text);
    }
}

bool testListOperations()
{
    List<int> numbers;
    expectTrue(numbers.isEmpty(), "A new list should start empty.");

    numbers.insertAtFront(2);
    numbers.insertAtFront(1);
    numbers.insertAtBack(3);

    std::string printed = captureOutput([&numbers]()
    {
        numbers.print();
    });

    expectContains(printed, "1 2 3", "List print order should reflect front and back inserts.");

    int removed = 0;
    expectTrue(numbers.removeFromFront(removed), "Removing from the front should succeed.");
    expectTrue(removed == 1, "The front element should be removed first.");

    expectTrue(numbers.removeFromBack(removed), "Removing from the back should succeed.");
    expectTrue(removed == 3, "The back element should be removed next.");

    expectTrue(numbers.removeFromFront(removed), "Removing the final element should succeed.");
    expectTrue(removed == 2, "The last remaining element should be 2.");
    expectTrue(numbers.isEmpty(), "The list should be empty after all removals.");

    return true;
}

bool testQueueFifoBehavior()
{
    Queue<std::string> tasks;
    expectTrue(tasks.isEmpty(), "A new queue should start empty.");

    tasks.enqueue("first");
    tasks.enqueue("second");
    tasks.enqueue("third");

    std::string removed;
    expectTrue(tasks.dequeue(removed), "The first dequeue should succeed.");
    expectTrue(removed == "first", "Queue should remove in FIFO order.");

    expectTrue(tasks.dequeue(removed), "The second dequeue should succeed.");
    expectTrue(removed == "second", "Queue should remove the second item next.");

    expectTrue(tasks.dequeue(removed), "The third dequeue should succeed.");
    expectTrue(removed == "third", "Queue should remove the third item last.");
    expectTrue(tasks.isEmpty(), "The queue should be empty after all dequeues.");

    return true;
}

bool testTask3Dispatch()
{
    NonVirtualDerived nonVirtualDerived;
    NonVirtualBase* nonVirtualPtr = &nonVirtualDerived;
    std::string nonVirtualOutput = captureOutput([nonVirtualPtr]()
    {
        nonVirtualPtr->testFunction();
    });
    expectContains(nonVirtualOutput, "Base class", "Without virtual, the base version should be called through a base pointer.");

    std::unique_ptr<Base> virtualPtr = std::make_unique<Derived>();
    std::string virtualOutput = captureOutput([&virtualPtr]()
    {
        virtualPtr->testFunction();
    });
    expectContains(virtualOutput, "Derived class", "With virtual, the derived version should be called through a base pointer.");

    return true;
}

bool testTask4DogPolymorphism()
{
    std::string output = captureOutput([]()
    {
        std::unique_ptr<Mammal> dog = std::make_unique<Dog>();
        dog->Move();
        dog->Speak();
    });

    expectContains(output, "Dog runs on four paws!", "A Dog object should override Move.");
    expectContains(output, "Dog says: Woof!", "A Dog object should override Speak.");

    return true;
}

bool testTask5AnimalSpeeches()
{
    std::string output = captureOutput([]()
    {
        std::vector<std::unique_ptr<Mammal>> animals;
        animals.emplace_back(std::make_unique<Dog>());
        animals.emplace_back(std::make_unique<Cat>());
        animals.emplace_back(std::make_unique<Horse>());
        animals.emplace_back(std::make_unique<GuineaPig>());
        animals.emplace_back(std::unique_ptr<Mammal>(createMammalFromChoice(99)));

        for (const auto& animal : animals)
        {
            animal->Speak();
        }
    });

    expectContains(output, "Dog says: Woof!", "Dog speech should be present.");
    expectContains(output, "Cat says: Meow!", "Cat speech should be present.");
    expectContains(output, "Horse says: Neigh!", "Horse speech should be present.");
    expectContains(output, "Guinea pig says: Weep weep!", "Guinea pig speech should be present.");
    expectContains(output, "What does a mammal speak? Mammilian!", "Invalid menu choices should default to Mammal.");

    return true;
}
}

bool runAllTests()
{
    const std::vector<std::pair<std::string, bool (*)()>> tests =
    {
        {"List operations", testListOperations},
        {"Queue FIFO behavior", testQueueFifoBehavior},
        {"Task 3 dispatch", testTask3Dispatch},
        {"Task 4 dog polymorphism", testTask4DogPolymorphism},
        {"Task 5 animal speeches", testTask5AnimalSpeeches}
    };

    bool allPassed = true;

    for (const auto& test : tests)
    {
        try
        {
            test.second();
            std::cout << "[PASS] " << test.first << std::endl;
        }
        catch (const std::exception& error)
        {
            allPassed = false;
            std::cout << "[FAIL] " << test.first << " - " << error.what() << std::endl;
        }
    }

    if (allPassed)
    {
        std::cout << "All tests passed." << std::endl;
    }
    else
    {
        std::cout << "Some tests failed." << std::endl;
    }

    return allPassed;
}

int main()
{
    return runAllTests() ? 0 : 1;
}
