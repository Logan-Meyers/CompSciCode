#pragma once

#include "Mammal.h"

class Cat : public Mammal
{
public:
    Cat();
    ~Cat() override;

    void Move() const override;
    void Speak() const override;
};
